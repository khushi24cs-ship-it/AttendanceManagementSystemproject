(function () {
  "use strict";

  function hasChart() {
    return typeof window.Chart !== "undefined";
  }

  if (hasChart()) {
    Chart.defaults.font.family = "Inter, system-ui, sans-serif";
    Chart.defaults.color = "#64748b";
    Chart.defaults.plugins.legend.labels.boxWidth = 12;
    Chart.defaults.plugins.legend.labels.usePointStyle = true;
    Chart.defaults.maintainAspectRatio = false;
  }

  var indigo = "#4f46e5";
  var green = "#059669";
  var amber = "#d97706";
  var red = "#dc2626";
  var sky = "#0ea5e9";

  function doughnut(id, labels, data, colors) {
    var el = document.getElementById(id);
    if (!el || !hasChart()) return;
    new Chart(el, {
      type: "doughnut",
      data: {
        labels: labels,
        datasets: [{ data: data, backgroundColor: colors, borderWidth: 0 }]
      },
      options: { plugins: { legend: { position: "bottom" } }, cutout: "68%" }
    });
  }

  function line(id, labels, data, color) {
    var el = document.getElementById(id);
    if (!el || !hasChart()) return;
    new Chart(el, {
      type: "line",
      data: {
        labels: labels,
        datasets: [{
          label: "Attendance %",
          data: data,
          borderColor: color || indigo,
          backgroundColor: "rgba(79,70,229,0.12)",
          fill: true,
          tension: 0.35,
          pointRadius: 3
        }]
      },
      options: {
        scales: {
          y: { min: 50, max: 100, grid: { color: "#eef1f7" } },
          x: { grid: { display: false } }
        }
      }
    });
  }

  function bar(id, labels, data, color) {
    var el = document.getElementById(id);
    if (!el || !hasChart()) return;
    new Chart(el, {
      type: "bar",
      data: {
        labels: labels,
        datasets: [{
          label: "Attendance %",
          data: data,
          backgroundColor: color || indigo,
          borderRadius: 8,
          maxBarThickness: 36
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          y: { min: 0, max: 100, grid: { color: "#eef1f7" } },
          x: { grid: { display: false } }
        }
      }
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    doughnut("overviewChart", ["Present", "Absent", "Late"], [84, 9, 7], [green, red, amber]);
    line("trendChart", ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], [81, 86, 79, 88, 84, 90, 87], indigo);
    doughnut("overallChart", ["Present", "Absent", "Late"], [78, 14, 8], [green, red, amber]);
    line("weeklyTrendChart", ["Week 1", "Week 2", "Week 3", "Week 4"], [76, 80, 82, 84], sky);
    bar("subjectChart", ["DBMS", "OS", "Java", "CN", "Web", "DS"], [82, 61, 76, 84, 79, 88], indigo);
    doughnut("riskChart", ["Safe", "Warning", "Critical"], [96, 16, 8], [green, amber, red]);
    line("teacherWeeklyChart", ["Mon", "Tue", "Wed", "Thu", "Fri"], [88, 82, 91, 86, 84], indigo);
    bar("teacherSubjectChart", ["DBMS", "OS", "Java"], [86, 64, 79], indigo);
    line("teacherTrendChart", ["W1", "W2", "W3", "W4", "W5", "W6"], [78, 80, 79, 83, 85, 86], green);
    doughnut("classAttendanceChart", ["Present", "Absent", "Late"], [52, 5, 3], [green, red, amber]);
    line("studentTrendChart", ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], [80, 75, 70, 82, 78, 84], indigo);
  });
})();
