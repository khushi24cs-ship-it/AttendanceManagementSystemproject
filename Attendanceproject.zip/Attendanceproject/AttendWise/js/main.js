(function () {
  "use strict";

  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }
  function qsa(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }

  window.AttendWise = window.AttendWise || {};

  AttendWise.toast = function (message, type) {
    var stack = qs(".toast-stack");
    if (!stack) {
      stack = document.createElement("div");
      stack.className = "toast-stack";
      document.body.appendChild(stack);
    }
    var el = document.createElement("div");
    el.className = "toast" + (type ? " " + type : "");
    el.textContent = message;
    stack.appendChild(el);
    setTimeout(function () {
      el.remove();
    }, 2800);
  };

  AttendWise.openModal = function (id) {
    var modal = document.getElementById(id);
    if (modal) modal.classList.add("open");
  };

  AttendWise.closeModal = function (id) {
    var modal = id ? document.getElementById(id) : null;
    if (modal) {
      modal.classList.remove("open");
      return;
    }
    qsa(".modal-backdrop.open").forEach(function (m) {
      m.classList.remove("open");
    });
  };

  AttendWise.confirmLogout = function () {
    if (window.confirm("Log out of AttendWise?")) {
      window.location.href = window.location.pathname.indexOf("/admin/") !== -1 ||
        window.location.pathname.indexOf("/teacher/") !== -1 ||
        window.location.pathname.indexOf("/student/") !== -1
        ? "../login.html"
        : "login.html";
    }
  };

  function setDates() {
    var now = new Date();
    var formatted = now.toLocaleDateString("en-IN", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    });
    qsa("[data-current-date]").forEach(function (el) {
      el.textContent = formatted;
    });
    qsa("[data-current-time]").forEach(function (el) {
      el.textContent = now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
    });
    qsa("[data-greeting]").forEach(function (el) {
      var h = now.getHours();
      var part = h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
      var name = el.getAttribute("data-name") || "";
      el.textContent = name ? part + ", " + name : part;
    });
  }

  function bindSidebar() {
    var sidebar = qs(".sidebar");
    var overlay = qs(".overlay");
    qsa("[data-toggle-sidebar]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        if (sidebar) sidebar.classList.toggle("open");
        if (overlay) overlay.classList.toggle("show");
      });
    });
    if (overlay) {
      overlay.addEventListener("click", function () {
        if (sidebar) sidebar.classList.remove("open");
        overlay.classList.remove("show");
      });
    }
  }

  function bindNav() {
    var nav = qs(".site-nav");
    qsa("[data-toggle-nav]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        if (nav) nav.classList.toggle("mobile-open");
      });
    });
  }

  function bindDropdowns() {
    qsa(".dropdown > button, .dropdown > .btn-icon").forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.stopPropagation();
        var drop = btn.closest(".dropdown");
        qsa(".dropdown.open").forEach(function (d) {
          if (d !== drop) d.classList.remove("open");
        });
        drop.classList.toggle("open");
      });
    });
    document.addEventListener("click", function () {
      qsa(".dropdown.open").forEach(function (d) {
        d.classList.remove("open");
      });
    });
  }

  function bindModals() {
    qsa("[data-open-modal]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        AttendWise.openModal(btn.getAttribute("data-open-modal"));
      });
    });
    qsa("[data-close-modal]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        AttendWise.closeModal(btn.getAttribute("data-close-modal"));
      });
    });
    qsa(".modal-backdrop").forEach(function (back) {
      back.addEventListener("click", function (e) {
        if (e.target === back) back.classList.remove("open");
      });
    });
  }

  function bindTabs() {
    qsa("[data-tabs]").forEach(function (group) {
      var tabs = qsa(".tab", group);
      tabs.forEach(function (tab) {
        tab.addEventListener("click", function () {
          tabs.forEach(function (t) { t.classList.remove("active"); });
          tab.classList.add("active");
          var target = tab.getAttribute("data-tab");
          var scope = group.parentElement || document;
          qsa("[data-tab-panel]", scope).forEach(function (panel) {
            panel.style.display = panel.getAttribute("data-tab-panel") === target ? "block" : "none";
          });
        });
      });
    });
  }

  function bindTableSearch() {
    qsa("[data-table-search]").forEach(function (input) {
      input.addEventListener("input", function () {
        var table = qs(input.getAttribute("data-table-search"));
        if (!table) return;
        var q = input.value.toLowerCase();
        qsa("tbody tr", table).forEach(function (row) {
          if (row.classList.contains("empty-row")) return;
          row.style.display = row.textContent.toLowerCase().indexOf(q) !== -1 ? "" : "none";
        });
      });
    });
  }

  function bindFilters() {
    qsa("[data-filter-table]").forEach(function (select) {
      select.addEventListener("change", applyFilters);
    });
  }

  function applyFilters() {
    qsa("table[data-filterable]").forEach(function (table) {
      var rows = qsa("tbody tr", table);
      rows.forEach(function (row) {
        if (row.classList.contains("empty-row")) return;
        var show = true;
        qsa("[data-filter-table='#" + table.id + "']").forEach(function (select) {
          var key = select.getAttribute("data-filter-key");
          var val = select.value;
          if (val && row.getAttribute("data-" + key) !== val) show = false;
        });
        row.style.display = show ? "" : "none";
      });
    });
  }

  function bindExport() {
    qsa("[data-export]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        AttendWise.toast("Export started. CSV download is a demo in Phase 2.", "success");
      });
    });
  }

  function bindDemoActions() {
    qsa("[data-demo-delete]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        if (!window.confirm("Remove this record from the current view? No database is connected yet.")) return;
        var row = btn.closest("tr");
        if (row) row.remove();
        AttendWise.toast("Record removed from this session.", "success");
      });
    });
    qsa("[data-mark-read]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var card = btn.closest(".notif-card");
        if (card) card.classList.remove("unread");
        AttendWise.toast("Marked as read.", "success");
      });
    });
    qsa("[data-delete-notif]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var card = btn.closest(".notif-card");
        if (card) card.remove();
        AttendWise.toast("Notification removed.", "success");
      });
    });
    qsa("[data-logout]").forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        AttendWise.confirmLogout();
      });
    });
  }

  function bindSettings() {
    qsa("[data-open-settings]").forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        AttendWise.openModal("settingsModal");
      });
    });
    qsa("[data-open-profile]").forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        AttendWise.openModal("profileModal");
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    setDates();
    bindSidebar();
    bindNav();
    bindDropdowns();
    bindModals();
    bindTabs();
    bindTableSearch();
    bindFilters();
    bindExport();
    bindDemoActions();
    bindSettings();
  });
})();
