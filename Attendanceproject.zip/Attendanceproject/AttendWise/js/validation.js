(function () {
  "use strict";

  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }
  function qsa(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }

  function showError(group, message) {
    group.classList.add("invalid");
    group.classList.remove("valid");
    var err = qs(".field-error", group);
    if (err) err.textContent = message;
  }

  function clearError(group) {
    group.classList.remove("invalid");
    group.classList.add("valid");
  }

  function emailValid(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function phoneValid(value) {
    return /^[6-9]\d{9}$/.test(value.replace(/\s+/g, ""));
  }

  function passwordStrength(value) {
    var score = 0;
    if (value.length >= 8) score += 1;
    if (/[A-Z]/.test(value)) score += 1;
    if (/[0-9]/.test(value)) score += 1;
    if (/[^A-Za-z0-9]/.test(value)) score += 1;
    return score;
  }

  function required(group, label) {
    var field = qs("input, select, textarea", group);
    if (!field) return true;
    if (!String(field.value).trim()) {
      showError(group, (label || "This field") + " is required.");
      return false;
    }
    clearError(group);
    return true;
  }

  window.AttendWise = window.AttendWise || {};
  AttendWise.validators = {
    emailValid: emailValid,
    phoneValid: phoneValid,
    passwordStrength: passwordStrength
  };

  function bindPasswordToggles() {
    qsa("[data-toggle-password]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var input = qs(btn.getAttribute("data-toggle-password"));
        if (!input) return;
        input.type = input.type === "password" ? "text" : "password";
        btn.setAttribute("aria-label", input.type === "password" ? "Show password" : "Hide password");
        var icon = qs("i", btn);
        if (icon) {
          icon.className = input.type === "password" ? "bi bi-eye" : "bi bi-eye-slash";
        }
      });
    });
  }

  function bindLogin() {
    var form = qs("#loginForm");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var emailGroup = qs("[data-field='email']", form);
      var passGroup = qs("[data-field='password']", form);
      var roleGroup = qs("[data-field='role']", form);
      var alertBox = qs(".form-alert", form);
      var ok = true;

      var email = qs("#loginEmail").value.trim();
      var password = qs("#loginPassword").value;
      var role = qs("#loginRole").value;

      if (!email) {
        showError(emailGroup, "Email is required.");
        ok = false;
      } else if (!emailValid(email)) {
        showError(emailGroup, "Enter a valid email address.");
        ok = false;
      } else {
        clearError(emailGroup);
      }

      if (!password) {
        showError(passGroup, "Password is required.");
        ok = false;
      } else if (password.length < 8) {
        showError(passGroup, "Password must be at least 8 characters.");
        ok = false;
      } else {
        clearError(passGroup);
      }

      if (!required(roleGroup, "Role")) ok = false;

      if (!ok) {
        alertBox.className = "form-alert error show";
        alertBox.textContent = "Please correct the highlighted fields.";
        return;
      }

      alertBox.className = "form-alert success show";
      alertBox.textContent = "Signed in successfully. Redirecting…";
      var map = { admin: "admin/dashboard.html", teacher: "teacher/dashboard.html", student: "student/dashboard.html" };
      setTimeout(function () {
        window.location.href = map[role] || "admin/dashboard.html";
      }, 700);
    });
  }

  function updateMeter(value) {
    var meter = qs("#passwordMeterBar");
    if (!meter) return;
    var score = passwordStrength(value);
    var widths = ["0%", "25%", "50%", "75%", "100%"];
    var colors = ["#dc2626", "#dc2626", "#d97706", "#0ea5e9", "#059669"];
    meter.style.width = widths[score];
    meter.style.background = colors[score];
  }

  function bindRegister() {
    var form = qs("#registerForm");
    if (!form) return;

    var role = qs("#regRole");
    var studentFields = qs("#studentFields");
    var teacherFields = qs("#teacherFields");

    function toggleRoleFields() {
      var value = role.value;
      studentFields.style.display = value === "student" ? "block" : "none";
      teacherFields.style.display = value === "teacher" ? "block" : "none";
    }
    role.addEventListener("change", toggleRoleFields);
    toggleRoleFields();

    qs("#regPassword").addEventListener("input", function () {
      updateMeter(this.value);
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var ok = true;
      var alertBox = qs(".form-alert", form);

      var nameGroup = qs("[data-field='name']", form);
      var emailGroup = qs("[data-field='email']", form);
      var passGroup = qs("[data-field='password']", form);
      var confirmGroup = qs("[data-field='confirm']", form);
      var roleGroup = qs("[data-field='role']", form);
      var phoneGroup = qs("[data-field='phone']", form);

      if (!required(nameGroup, "Full name")) ok = false;
      var email = qs("#regEmail").value.trim();
      if (!email) {
        showError(emailGroup, "Email is required.");
        ok = false;
      } else if (!emailValid(email)) {
        showError(emailGroup, "Enter a valid email address.");
        ok = false;
      } else clearError(emailGroup);

      var password = qs("#regPassword").value;
      if (!password) {
        showError(passGroup, "Password is required.");
        ok = false;
      } else if (password.length < 8) {
        showError(passGroup, "Use at least 8 characters.");
        ok = false;
      } else if (passwordStrength(password) < 3) {
        showError(passGroup, "Use upper case, a number, and a symbol.");
        ok = false;
      } else clearError(passGroup);

      var confirm = qs("#regConfirm").value;
      if (confirm !== password) {
        showError(confirmGroup, "Passwords do not match.");
        ok = false;
      } else if (!confirm) {
        showError(confirmGroup, "Confirm your password.");
        ok = false;
      } else clearError(confirmGroup);

      if (!required(roleGroup, "Role")) ok = false;

      var phone = qs("#regPhone").value.trim();
      if (!phone) {
        showError(phoneGroup, "Phone number is required.");
        ok = false;
      } else if (!phoneValid(phone)) {
        showError(phoneGroup, "Enter a valid 10-digit Indian mobile number.");
        ok = false;
      } else clearError(phoneGroup);

      if (role.value === "student") {
        if (!required(qs("[data-field='roll']", form), "Roll number")) ok = false;
        if (!required(qs("[data-field='course']", form), "Course")) ok = false;
        if (!required(qs("[data-field='semester']", form), "Semester")) ok = false;
      }
      if (role.value === "teacher") {
        if (!required(qs("[data-field='empid']", form), "Employee ID")) ok = false;
        if (!required(qs("[data-field='dept']", form), "Department")) ok = false;
      }

      if (!ok) {
        alertBox.className = "form-alert error show";
        alertBox.textContent = "Please fix the errors before creating your account.";
        return;
      }

      alertBox.className = "form-alert success show";
      alertBox.textContent = "Account created. You can now sign in.";
      setTimeout(function () {
        window.location.href = "login.html";
      }, 900);
    });
  }

  function bindGenericForms() {
    qsa("form[data-validate]").forEach(function (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        var ok = true;
        qsa("[data-required]", form).forEach(function (group) {
          if (!required(group, group.getAttribute("data-label") || "This field")) ok = false;
        });
        qsa("[data-email]", form).forEach(function (group) {
          var input = qs("input", group);
          if (input.value && !emailValid(input.value.trim())) {
            showError(group, "Enter a valid email address.");
            ok = false;
          }
        });
        qsa("[data-phone]", form).forEach(function (group) {
          var input = qs("input", group);
          if (input.value && !phoneValid(input.value.trim())) {
            showError(group, "Enter a valid 10-digit phone number.");
            ok = false;
          }
        });
        if (!ok) {
          if (window.AttendWise && AttendWise.toast) AttendWise.toast("Please complete the required fields.", "error");
          return;
        }
        if (window.AttendWise && AttendWise.toast) AttendWise.toast("Saved for this session. Backend will be added in a later phase.", "success");
        var closeId = form.getAttribute("data-close-on-success");
        if (closeId && window.AttendWise) AttendWise.closeModal(closeId);
        form.reset();
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    bindPasswordToggles();
    bindLogin();
    bindRegister();
    bindGenericForms();
  });
})();
