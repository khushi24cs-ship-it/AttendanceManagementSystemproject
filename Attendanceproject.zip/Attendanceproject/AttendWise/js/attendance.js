(function () {
  "use strict";

  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }
  function qsa(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }

  function bindMarkAttendance() {
    var table = qs("#markTable");
    if (!table) return;

    var names = ["Aarav Sharma", "Riya Patel", "Rahul Mehta", "Sneha Desai", "Aditya Shah", "Ananya Joshi", "Kabir Kapoor", "Neha Kulkarni"];
    var body = qs("tbody", table);
    if (body && table.getAttribute("data-generate") === "60") {
      var html = "";
      for (var i = 1; i <= 60; i += 1) {
        var status = i <= 52 ? "present" : i <= 55 ? "late" : "absent";
        var name = names[(i - 1) % names.length];
        var roll = "TYCS" + String(i).padStart(2, "0");
        html += '<tr data-status="' + status + '"><td>' + i + "</td><td>" + roll + "</td><td>" + name +
          '</td><td><button type="button" class="att-btn present' + (status === "present" ? " active" : "") + '" data-status="present">Present</button></td>' +
          '<td><button type="button" class="att-btn late' + (status === "late" ? " active" : "") + '" data-status="late">Late</button></td>' +
          '<td><button type="button" class="att-btn absent' + (status === "absent" ? " active" : "") + '" data-status="absent">Absent</button></td></tr>';
      }
      body.innerHTML = html;
    }

    function setStatus(row, status) {
      row.setAttribute("data-status", status);
      qsa(".att-btn", row).forEach(function (btn) {
        btn.classList.toggle("active", btn.getAttribute("data-status") === status);
      });
      updateCounters();
    }

    function updateCounters() {
      var rows = qsa("tbody tr", table);
      var present = 0, absent = 0, late = 0;
      rows.forEach(function (row) {
        var s = row.getAttribute("data-status");
        if (s === "present") present += 1;
        if (s === "absent") absent += 1;
        if (s === "late") late += 1;
      });
      var total = rows.length;
      var pct = total ? ((present + late * 0.5) / total * 100) : 0;
      qs("#countPresent").textContent = present;
      qs("#countAbsent").textContent = absent;
      qs("#countLate").textContent = late;
      qs("#countTotal").textContent = total;
      qs("#countPct").textContent = pct.toFixed(1) + "%";
      localStorage.setItem("attendwise_mark_preview", JSON.stringify({
        present: present, absent: absent, late: late, total: total, pct: pct.toFixed(1)
      }));
    }

    table.addEventListener("click", function (e) {
      var btn = e.target.closest(".att-btn");
      if (!btn) return;
      setStatus(btn.closest("tr"), btn.getAttribute("data-status"));
    });

    var markAll = qs("#markAllPresent");
    if (markAll) {
      markAll.addEventListener("click", function () {
        qsa("tbody tr", table).forEach(function (row) { setStatus(row, "present"); });
        if (window.AttendWise) AttendWise.toast("All students marked present.", "success");
      });
    }

    var reset = qs("#resetAttendance");
    if (reset) {
      reset.addEventListener("click", function () {
        qsa("tbody tr", table).forEach(function (row) { setStatus(row, "present"); });
        if (window.AttendWise) AttendWise.toast("Attendance reset to present.", "success");
      });
    }

    var save = qs("#saveAttendance");
    if (save) {
      save.addEventListener("click", function () {
        if (window.AttendWise) AttendWise.openModal("saveAttendanceModal");
      });
    }

    var confirm = qs("#confirmSaveAttendance");
    if (confirm) {
      confirm.addEventListener("click", function () {
        updateCounters();
        if (window.AttendWise) {
          AttendWise.closeModal("saveAttendanceModal");
          AttendWise.toast("Attendance saved in this browser session.", "success");
        }
      });
    }

    updateCounters();
  }

  document.addEventListener("DOMContentLoaded", bindMarkAttendance);
})();
