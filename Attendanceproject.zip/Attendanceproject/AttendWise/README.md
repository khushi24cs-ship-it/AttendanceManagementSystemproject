# AttendWise — Smart Attendance & Student Analytics System

Phase 2 frontend prototype for a college Web Technology project.

**Tagline:** Track. Analyze. Improve.

AttendWise is a role-based attendance product for **TY Computer Science, Division A, Academic Year 2026–27**. There is no PHP/MySQL in this phase. Data on screen is sample data, with JavaScript and `localStorage` used only for UI demonstration.

## How to run

1. Open the `AttendWise` folder.
2. Double-click `index.html`, or right-click a page in VS Code / Cursor and use Live Server.
3. Use **Get Started** / **Login**.
4. On the login page, enter any valid email, a password of at least 8 characters, and choose a role:
   - Admin → `admin/dashboard.html`
   - Teacher → `teacher/dashboard.html`
   - Student → `student/dashboard.html`

Internet is required once for Google Fonts, Bootstrap Icons, and Chart.js CDNs.

## Roles

| Role | Purpose |
| --- | --- |
| Admin | Students, teachers, courses, subjects, class, attendance, analytics, notifications |
| Teacher | Mark attendance, history, students, analytics |
| Student | Personal attendance, history, alerts |

The system has **one division only: Division A**.

## Folder structure

```
AttendWise/
├── index.html
├── login.html
├── register.html
├── admin/
├── teacher/
├── student/
├── css/
├── js/
├── images/
└── README.md
```

## Tech (Phase 2)

- HTML5
- CSS3 (custom design system, no Tailwind)
- JavaScript (no React / Vue / Node)
- Chart.js for dashboards
- Bootstrap Icons CDN

PHP + MySQL will be connected in a later phase. Form `id` and `name` attributes are kept simple so they can map to backend fields later.
