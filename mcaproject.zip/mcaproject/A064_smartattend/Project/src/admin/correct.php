<?php
require_once __DIR__ . '/../functions.php';
require_role('Admin');
$pdo = get_pdo();
$user = current_user();
$errors = [];
$sessionId = get_int('session_id') ?: post_int('session_id');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && post_str('action') === 'correct') {
    require_csrf();
    $reason = post_str('reason');
    $statuses = $_POST['status'] ?? [];
    if ($reason === '') {
        $errors[] = 'A correction reason is mandatory.';
    }
    if (!$sessionId) {
        $errors[] = 'Select a finalized session first.';
    }
    if (!$errors && is_array($statuses)) {
        try {
            $pdo->beginTransaction();
            foreach ($statuses as $attendanceId => $status) {
                $attendanceId = (int) $attendanceId;
                $status = strtoupper(trim((string) $status));
                if (!is_valid_status($status)) {
                    throw new InvalidArgumentException('Invalid attendance status.');
                }
                $owns = $pdo->prepare('SELECT attendance_id FROM attendance_records WHERE attendance_id = ? AND session_id = ?');
                $owns->execute([$attendanceId, $sessionId]);
                if (!$owns->fetch()) {
                    throw new RuntimeException('Invalid attendance record.');
                }
                correct_attendance($pdo, $attendanceId, $status, $reason, $user['user_id'], false);
            }
            $pdo->commit();
            flash_set('success', 'Attendance corrections were saved and added to the audit log. Reports now use the updated marks.');
            redirect('admin/correct.php?session_id=' . $sessionId);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'The correction could not be saved. Existing records were left unchanged.';
        }
    }
}

$sessions = $pdo->query(
    'SELECT s.session_id, s.session_date, s.status, sub.subject_code, c.semester, c.division
     FROM attendance_sessions s
     JOIN class_subjects cs ON cs.class_subject_id = s.class_subject_id
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN classes c ON c.class_id = cs.class_id
     WHERE s.status = \'FINALIZED\'
     ORDER BY s.session_date DESC'
)->fetchAll();

$records = [];
$sessionMeta = null;
if ($sessionId) {
    $meta = $pdo->prepare(
        'SELECT s.session_id, s.session_date, s.start_time, s.end_time, s.status, sub.subject_code, sub.subject_name,
                c.semester, c.division, co.course_code
         FROM attendance_sessions s
         JOIN class_subjects cs ON cs.class_subject_id = s.class_subject_id
         JOIN subjects sub ON sub.subject_id = cs.subject_id
         JOIN classes c ON c.class_id = cs.class_id
         JOIN courses co ON co.course_id = c.course_id
         WHERE s.session_id = ? AND s.status = \'FINALIZED\''
    );
    $meta->execute([$sessionId]);
    $sessionMeta = $meta->fetch() ?: null;
    if ($sessionMeta) {
        $stmt = $pdo->prepare(
            'SELECT r.attendance_id, r.attendance_status, st.roll_no, u.name
             FROM attendance_records r
             JOIN students st ON st.student_id = r.student_id
             JOIN users u ON u.user_id = st.user_id
             WHERE r.session_id = ?
             ORDER BY st.roll_no'
        );
        $stmt->execute([$sessionId]);
        $records = $stmt->fetchAll();
    }
}

$pageTitle = 'Correct Attendance';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2>Select a finalized session</h2>
    <form method="get">
        <label for="session_id">Session
            <select id="session_id" name="session_id" required>
                <option value="">Select</option>
                <?php foreach ($sessions as $s): ?>
                    <option value="<?= (int) $s['session_id'] ?>" <?= $sessionId === (int) $s['session_id'] ? 'selected' : '' ?>>
                        <?= e($s['session_date'] . ' | ' . $s['subject_code'] . ' | Sem ' . $s['semester'] . '-' . $s['division']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <button type="submit">Load</button>
    </form>
</div>
<?php if ($sessionMeta): ?>
<div class="card">
    <h2>Update marks</h2>
    <div class="session-meta">
        <div><span>Class</span><strong><?= e($sessionMeta['course_code'] . ' Sem ' . $sessionMeta['semester'] . '-' . $sessionMeta['division']) ?></strong></div>
        <div><span>Subject</span><strong><?= e($sessionMeta['subject_code'] . ' - ' . $sessionMeta['subject_name']) ?></strong></div>
        <div><span>Date</span><strong><?= e($sessionMeta['session_date']) ?></strong></div>
        <div><span>Time</span><strong><?= e(substr($sessionMeta['start_time'], 0, 5) . ' - ' . substr($sessionMeta['end_time'], 0, 5)) ?></strong></div>
    </div>
    <?php foreach ($errors as $err): ?><div class="alert alert-error" role="alert"><?= e($err) ?></div><?php endforeach; ?>
    <?php if (!$records): ?>
        <p class="muted">This session has no saved marks yet. Incomplete data still counts in reports if the session is finalized.</p>
    <?php else: ?>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="correct">
        <input type="hidden" name="session_id" value="<?= (int) $sessionId ?>">
        <div class="table-wrap">
        <table>
            <thead><tr><th>Roll</th><th>Name</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($records as $r): ?>
                <tr>
                    <td><?= e($r['roll_no']) ?></td>
                    <td><?= e($r['name']) ?></td>
                    <td>
                        <select name="status[<?= (int) $r['attendance_id'] ?>]" aria-label="Status for <?= e($r['name']) ?>">
                            <?php foreach (['PRESENT', 'ABSENT', 'LATE'] as $st): ?>
                                <option value="<?= $st ?>" <?= $r['attendance_status'] === $st ? 'selected' : '' ?>><?= $st ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <label for="reason">Reason for correction
            <textarea id="reason" name="reason" required rows="3" maxlength="255" placeholder="Required for the audit log"></textarea>
        </label>
        <button type="submit" data-confirm="Save these corrections to the audit log?">Save corrections</button>
    </form>
    <?php endif; ?>
</div>
<?php elseif ($sessionId): ?>
<div class="card"><p>That session is not available for correction.</p></div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
