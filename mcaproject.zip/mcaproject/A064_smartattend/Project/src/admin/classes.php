<?php
require_once __DIR__ . '/../functions.php';
require_role('Admin');
$pdo = get_pdo();
$errors = [];
$editId = get_int('id');
$edit = null;
if ($editId) {
    $stmt = $pdo->prepare('SELECT * FROM classes WHERE class_id = ?');
    $stmt->execute([$editId]);
    $edit = $stmt->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $id = post_int('class_id');
    $courseId = post_int('course_id');
    $sem = post_int('semester');
    $div = post_str('division');
    $year = post_str('academic_year');
    if (!$courseId || $sem < 1 || $div === '' || $year === '') {
        $errors[] = 'Course, semester, division, and academic year are required.';
    }
    $exists = $pdo->prepare('SELECT course_id FROM courses WHERE course_id = ?');
    $exists->execute([$courseId]);
    if (!$exists->fetch()) {
        $errors[] = 'Selected course does not exist.';
    }
    $dup = $pdo->prepare('SELECT class_id FROM classes WHERE course_id = ? AND semester = ? AND division = ? AND academic_year = ? AND class_id <> ?');
    $dup->execute([$courseId, $sem, $div, $year, $id]);
    if ($dup->fetch()) {
        $errors[] = 'This class already exists for the selected course, semester, division, and year.';
    }
    if (!$errors) {
        if ($id) {
            $pdo->prepare('UPDATE classes SET course_id = ?, semester = ?, division = ?, academic_year = ? WHERE class_id = ?')
                ->execute([$courseId, $sem, $div, $year, $id]);
            flash_set('success', 'Class updated.');
        } else {
            $pdo->prepare('INSERT INTO classes (course_id, semester, division, academic_year) VALUES (?, ?, ?, ?)')
                ->execute([$courseId, $sem, $div, $year]);
            flash_set('success', 'Class added.');
        }
        redirect('admin/classes.php');
    }
}

$courses = $pdo->query('SELECT * FROM courses ORDER BY course_code')->fetchAll();
$list = $pdo->query(
    'SELECT c.*, co.course_code, co.course_name FROM classes c JOIN courses co ON co.course_id = c.course_id ORDER BY co.course_code, c.semester'
)->fetchAll();
$pageTitle = 'Manage Classes';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2><?= $edit ? 'Edit class' : 'Add class' ?></h2>
    <?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="class_id" value="<?= $edit ? (int) $edit['class_id'] : 0 ?>">
        <div class="form-row">
            <label>Course
                <select name="course_id" required>
                    <option value="">Select</option>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?= (int) $c['course_id'] ?>" <?= ((int) ($edit['course_id'] ?? $_POST['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                            <?= e($c['course_code'] . ' - ' . $c['course_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Semester <input type="number" name="semester" min="1" max="10" required value="<?= e((string) ($edit['semester'] ?? $_POST['semester'] ?? '1')) ?>"></label>
            <label>Division <input type="text" name="division" required value="<?= e($edit['division'] ?? $_POST['division'] ?? 'A') ?>"></label>
            <label>Academic year <input type="text" name="academic_year" required placeholder="2025-26" value="<?= e($edit['academic_year'] ?? $_POST['academic_year'] ?? '2025-26') ?>"></label>
        </div>
        <button type="submit">Save</button>
        <?php if ($edit): ?><a class="btn btn-secondary" href="<?= e(src_url('admin/classes.php')) ?>">Cancel</a><?php endif; ?>
    </form>
</div>
<div class="card">
    <h2>Classes</h2>
    <table>
        <thead><tr><th data-sort>Course</th><th data-sort>Semester</th><th>Division</th><th>Year</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($list as $row): ?>
            <tr>
                <td><?= e($row['course_code'] . ' - ' . $row['course_name']) ?></td>
                <td><?= (int) $row['semester'] ?></td>
                <td><?= e($row['division']) ?></td>
                <td><?= e($row['academic_year']) ?></td>
                <td><a class="btn btn-small btn-outline" href="?id=<?= (int) $row['class_id'] ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$list): ?>
            <tr class="empty-row"><td colspan="5">No classes have been added yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
