<?php
require_once __DIR__ . '/../functions.php';
require_role('Admin');
$pdo = get_pdo();
$errors = [];
$editId = get_int('id');
$edit = null;

if ($editId) {
    $stmt = $pdo->prepare(
        'SELECT s.*, u.name, u.email, u.is_active FROM students s JOIN users u ON u.user_id = s.user_id WHERE s.student_id = ?'
    );
    $stmt->execute([$editId]);
    $edit = $stmt->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = post_str('action');

    if ($action === 'deactivate') {
        $sid = post_int('student_id');
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT user_id FROM students WHERE student_id = ?');
            $stmt->execute([$sid]);
            $uid = $stmt->fetchColumn();
            if ($uid) {
                $pdo->prepare("UPDATE students SET status = 'Inactive' WHERE student_id = ?")->execute([$sid]);
                $pdo->prepare('UPDATE users SET is_active = 0 WHERE user_id = ?')->execute([$uid]);
            }
            $pdo->commit();
            flash_set('success', 'Student account deactivated. Attendance history was kept.');
        } catch (Throwable $e) {
            $pdo->rollBack();
            flash_set('error', 'Could not deactivate the student.');
        }
        redirect('admin/students.php');
    }

    $name = post_str('name');
    $email = post_str('email');
    $roll = post_str('roll_no');
    $classId = post_int('class_id');
    $year = post_int('admission_year');
    $password = (string) ($_POST['password'] ?? '');
    $studentId = post_int('student_id');

    if ($name === '' || $email === '' || $roll === '' || !$classId || !$year) {
        $errors[] = 'Name, email, roll number, class, and admission year are required.';
    }
    if (!is_valid_email($email)) {
        $errors[] = 'Enter a valid email address.';
    }
    $cls = $pdo->prepare('SELECT class_id FROM classes WHERE class_id = ?');
    $cls->execute([$classId]);
    if (!$cls->fetch()) {
        $errors[] = 'Selected class does not exist.';
    }

    $emailStmt = $pdo->prepare('SELECT user_id FROM users WHERE email = ? AND user_id <> ?');
    $userId = $studentId ? (int) ($edit['user_id'] ?? 0) : 0;
    $emailStmt->execute([$email, $userId]);
    if ($emailStmt->fetch()) {
        $errors[] = 'This email is already registered.';
    }
    $rollStmt = $pdo->prepare('SELECT student_id FROM students WHERE roll_no = ? AND student_id <> ?');
    $rollStmt->execute([$roll, $studentId]);
    if ($rollStmt->fetch()) {
        $errors[] = 'This roll number is already in use.';
    }
    if (!$studentId && strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters for a new student.';
    }

    if (!$errors) {
        try {
            if ($studentId && $edit) {
                $pdo->beginTransaction();
                $pdo->prepare('UPDATE users SET name = ?, email = ? WHERE user_id = ?')->execute([$name, $email, $edit['user_id']]);
                $pdo->prepare('UPDATE students SET roll_no = ?, class_id = ?, admission_year = ? WHERE student_id = ?')
                    ->execute([$roll, $classId, $year, $studentId]);
                if ($password !== '') {
                    $pdo->prepare('UPDATE users SET password_hash = ? WHERE user_id = ?')
                        ->execute([password_hash($password, PASSWORD_DEFAULT), $edit['user_id']]);
                }
                $pdo->commit();
                flash_set('success', 'Student details updated.');
            } else {
                $pdo->beginTransaction();
                $pdo->prepare('INSERT INTO users (name, email, password_hash, role, is_active) VALUES (?, ?, ?, ?, 1)')
                    ->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), 'Student']);
                $uid = (int) $pdo->lastInsertId();
                $pdo->prepare('INSERT INTO students (user_id, roll_no, class_id, admission_year, status) VALUES (?, ?, ?, ?, ?)')
                    ->execute([$uid, $roll, $classId, $year, 'Active']);
                $pdo->commit();
                flash_set('success', 'Student account created.');
            }
            redirect('admin/students.php');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'Could not save the student. Check for duplicate values.';
        }
    }
}

$classes = $pdo->query(
    'SELECT c.class_id, c.semester, c.division, c.academic_year, co.course_code
     FROM classes c JOIN courses co ON co.course_id = c.course_id ORDER BY co.course_code, c.semester'
)->fetchAll();
$list = $pdo->query(
    'SELECT s.student_id, s.roll_no, s.admission_year, s.status, u.name, u.email, u.is_active,
            c.semester, c.division, c.academic_year, co.course_code
     FROM students s
     JOIN users u ON u.user_id = s.user_id
     JOIN classes c ON c.class_id = s.class_id
     JOIN courses co ON co.course_id = c.course_id
     ORDER BY s.roll_no'
)->fetchAll();

$pageTitle = 'Manage Students';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2><?= $edit ? 'Edit student' : 'Add student' ?></h2>
    <?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="student_id" value="<?= $edit ? (int) $edit['student_id'] : 0 ?>">
        <div class="form-row">
            <label>Name <input type="text" name="name" required value="<?= e($edit['name'] ?? $_POST['name'] ?? '') ?>"></label>
            <label>Email <input type="email" name="email" required value="<?= e($edit['email'] ?? $_POST['email'] ?? '') ?>"></label>
            <label>Roll number <input type="text" name="roll_no" required value="<?= e($edit['roll_no'] ?? $_POST['roll_no'] ?? '') ?>"></label>
            <label>Class
                <select name="class_id" required>
                    <option value="">Select</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?= (int) $c['class_id'] ?>" <?= ((int) ($edit['class_id'] ?? $_POST['class_id'] ?? 0) === (int) $c['class_id']) ? 'selected' : '' ?>>
                            <?= e($c['course_code'] . ' Sem ' . $c['semester'] . ' Div ' . $c['division'] . ' (' . $c['academic_year'] . ')') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Admission year <input type="number" name="admission_year" required min="2000" max="2100" value="<?= e((string) ($edit['admission_year'] ?? $_POST['admission_year'] ?? date('Y'))) ?>"></label>
            <label><?= $edit ? 'New password (optional)' : 'Password' ?>
                <input type="password" name="password" <?= $edit ? '' : 'required minlength="6"' ?>>
            </label>
        </div>
        <button type="submit"><?= $edit ? 'Update student' : 'Add student' ?></button>
        <?php if ($edit): ?><a class="btn btn-secondary" href="<?= e(src_url('admin/students.php')) ?>">Cancel</a><?php endif; ?>
    </form>
</div>
<div class="card">
    <h2>Student accounts</h2>
    <?= table_search('Search students') ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th data-sort>Roll</th>
                <th data-sort>Name</th>
                <th data-sort>Email</th>
                <th data-sort>Class</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($list as $row): ?>
            <tr>
                <td><?= e($row['roll_no']) ?></td>
                <td><?= e($row['name']) ?></td>
                <td><?= e($row['email']) ?></td>
                <td><?= e($row['course_code'] . ' Sem ' . $row['semester'] . '-' . $row['division']) ?></td>
                <td><span class="badge badge-<?= e($row['status']) ?>"><?= e($row['status']) ?></span></td>
                <td>
                    <a class="btn btn-small btn-outline" href="?id=<?= (int) $row['student_id'] ?>">Edit</a>
                    <?php if ($row['status'] === 'Active'): ?>
                    <form method="post" style="display:inline">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="deactivate">
                        <input type="hidden" name="student_id" value="<?= (int) $row['student_id'] ?>">
                        <button class="btn btn-small btn-danger" data-confirm="Deactivate this student? Attendance history and records will be preserved.">Deactivate</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$list): ?>
            <tr class="empty-row"><td colspan="6">No students have been added yet. Use the form above to add the first one.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
