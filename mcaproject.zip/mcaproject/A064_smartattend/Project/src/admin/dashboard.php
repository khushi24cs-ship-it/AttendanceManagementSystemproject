<?php
require_once __DIR__ . '/../functions.php';
require_role('Admin');
$pdo = get_pdo();

$counts = [
    'students' => (int) $pdo->query("SELECT COUNT(*) FROM students s JOIN users u ON u.user_id = s.user_id WHERE u.is_active = 1 AND s.status = 'Active'")->fetchColumn(),
    'teachers' => (int) $pdo->query("SELECT COUNT(*) FROM teachers t JOIN users u ON u.user_id = t.user_id WHERE u.is_active = 1")->fetchColumn(),
    'courses'  => (int) $pdo->query('SELECT COUNT(*) FROM courses')->fetchColumn(),
    'classes'  => (int) $pdo->query('SELECT COUNT(*) FROM classes')->fetchColumn(),
    'subjects' => (int) $pdo->query('SELECT COUNT(*) FROM subjects')->fetchColumn(),
    'sessions' => (int) $pdo->query("SELECT COUNT(*) FROM attendance_sessions WHERE status = 'FINALIZED'")->fetchColumn(),
];

$below = (int) $pdo->query(
    "SELECT COUNT(*) FROM (
        SELECT s.student_id, cs.class_subject_id,
               COUNT(sess.session_id) AS total,
               SUM(CASE WHEN r.attendance_status IN ('PRESENT','LATE') THEN 1 ELSE 0 END) AS attended
        FROM class_subjects cs
        JOIN students s ON s.class_id = cs.class_id
        JOIN attendance_sessions sess ON sess.class_subject_id = cs.class_subject_id AND sess.status = 'FINALIZED'
        LEFT JOIN attendance_records r ON r.session_id = sess.session_id AND r.student_id = s.student_id
        GROUP BY s.student_id, cs.class_subject_id
        HAVING total > 0 AND (attended / total) * 100 < " . (int) MIN_ATTENDANCE_PERCENT . '
     ) deficit'
)->fetchColumn();

// Recent audit entries (last 5)
$recentAudit = $pdo->query(
    "SELECT a.changed_at, u.name AS changed_by_name, su.name AS student_name,
            sub.subject_code, a.old_status, a.new_status
     FROM attendance_audit_logs a
     JOIN users u ON u.user_id = a.changed_by
     JOIN attendance_records r ON r.attendance_id = a.attendance_id
     JOIN students st ON st.student_id = r.student_id
     JOIN users su ON su.user_id = st.user_id
     JOIN attendance_sessions sess ON sess.session_id = r.session_id
     JOIN class_subjects cs ON cs.class_subject_id = sess.class_subject_id
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     ORDER BY a.changed_at DESC LIMIT 5"
)->fetchAll();

$pageTitle = 'Admin Dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="grid">
    <div class="card">
        <h3>Active students</h3>
        <div class="stat"><?= $counts['students'] ?></div>
    </div>
    <div class="card">
        <h3>Active teachers</h3>
        <div class="stat"><?= $counts['teachers'] ?></div>
    </div>
    <div class="card">
        <h3>Courses</h3>
        <div class="stat"><?= $counts['courses'] ?></div>
    </div>
    <div class="card">
        <h3>Classes</h3>
        <div class="stat"><?= $counts['classes'] ?></div>
    </div>
    <div class="card">
        <h3>Subjects</h3>
        <div class="stat"><?= $counts['subjects'] ?></div>
    </div>
    <div class="card">
        <h3>Finalized sessions</h3>
        <div class="stat"><?= $counts['sessions'] ?></div>
    </div>
    <div class="card">
        <h3>Below 80% attendance</h3>
        <div class="stat <?= $below > 0 ? 'text-bad' : '' ?>"><?= $below ?></div>
        <div class="stat-note">Student&ndash;subject pairs</div>
    </div>
</div>
<div class="card">
    <h2>Quick actions</h2>
    <div class="actions">
        <a class="btn" href="<?= e(src_url('admin/students.php')) ?>">Manage students</a>
        <a class="btn" href="<?= e(src_url('admin/teachers.php')) ?>">Manage teachers</a>
        <a class="btn btn-secondary" href="<?= e(src_url('admin/reports.php')) ?>">Open reports</a>
        <a class="btn btn-secondary" href="<?= e(src_url('admin/correct.php')) ?>">Correct attendance</a>
        <a class="btn btn-outline" href="<?= e(src_url('admin/audit.php')) ?>">View audit log</a>
    </div>
</div>
<?php if ($recentAudit): ?>
<div class="card">
    <h2>Recent attendance corrections</h2>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>When</th>
                <th>Student</th>
                <th>Subject</th>
                <th>Change</th>
                <th>By</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($recentAudit as $row): ?>
            <tr>
                <td><?= e(date('d M Y H:i', strtotime($row['changed_at']))) ?></td>
                <td><?= e($row['student_name']) ?></td>
                <td><?= e($row['subject_code']) ?></td>
                <td>
                    <span class="badge badge-<?= e($row['old_status']) ?>"><?= e($row['old_status']) ?></span>
                    &rarr;
                    <span class="badge badge-<?= e($row['new_status']) ?>"><?= e($row['new_status']) ?></span>
                </td>
                <td><?= e($row['changed_by_name']) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <p class="muted text-sm" style="margin-top:0.6rem"><a href="<?= e(src_url('admin/audit.php')) ?>">View full audit log &rarr;</a></p>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
