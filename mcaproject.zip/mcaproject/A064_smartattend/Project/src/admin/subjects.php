<?php
require_once __DIR__ . '/../functions.php';
require_role('Admin');
$pdo = get_pdo();
$errors = [];
$editId = get_int('id');
$edit = null;
if ($editId) {
    $stmt = $pdo->prepare('SELECT * FROM subjects WHERE subject_id = ?');
    $stmt->execute([$editId]);
    $edit = $stmt->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $id = post_int('subject_id');
    $courseId = post_int('course_id');
    $code = post_str('subject_code');
    $name = post_str('subject_name');
    $sem = post_int('semester');
    $credits = post_int('credits');
    if (!$courseId || $code === '' || $name === '' || $sem < 1 || $credits < 1) {
        $errors[] = 'All subject fields are required.';
    }
    $exists = $pdo->prepare('SELECT course_id FROM courses WHERE course_id = ?');
    $exists->execute([$courseId]);
    if (!$exists->fetch()) {
        $errors[] = 'Selected course does not exist.';
    }
    $dup = $pdo->prepare('SELECT subject_id FROM subjects WHERE course_id = ? AND subject_code = ? AND subject_id <> ?');
    $dup->execute([$courseId, $code, $id]);
    if ($dup->fetch()) {
        $errors[] = 'This subject code already exists in the selected course.';
    }
    if (!$errors) {
        if ($id) {
            $pdo->prepare('UPDATE subjects SET course_id = ?, subject_code = ?, subject_name = ?, semester = ?, credits = ? WHERE subject_id = ?')
                ->execute([$courseId, $code, $name, $sem, $credits, $id]);
            flash_set('success', 'Subject updated.');
        } else {
            $pdo->prepare('INSERT INTO subjects (course_id, subject_code, subject_name, semester, credits) VALUES (?, ?, ?, ?, ?)')
                ->execute([$courseId, $code, $name, $sem, $credits]);
            flash_set('success', 'Subject added.');
        }
        redirect('admin/subjects.php');
    }
}

$courses = $pdo->query('SELECT * FROM courses ORDER BY course_code')->fetchAll();
$list = $pdo->query(
    'SELECT s.*, co.course_code FROM subjects s JOIN courses co ON co.course_id = s.course_id ORDER BY co.course_code, s.subject_code'
)->fetchAll();
$pageTitle = 'Manage Subjects';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2><?= $edit ? 'Edit subject' : 'Add subject' ?></h2>
    <?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="subject_id" value="<?= $edit ? (int) $edit['subject_id'] : 0 ?>">
        <div class="form-row">
            <label>Course
                <select name="course_id" required>
                    <option value="">Select</option>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?= (int) $c['course_id'] ?>" <?= ((int) ($edit['course_id'] ?? $_POST['course_id'] ?? 0) === (int) $c['course_id']) ? 'selected' : '' ?>>
                            <?= e($c['course_code']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Code <input type="text" name="subject_code" required value="<?= e($edit['subject_code'] ?? $_POST['subject_code'] ?? '') ?>"></label>
            <label>Name <input type="text" name="subject_name" required value="<?= e($edit['subject_name'] ?? $_POST['subject_name'] ?? '') ?>"></label>
            <label>Semester <input type="number" name="semester" min="1" max="10" required value="<?= e((string) ($edit['semester'] ?? $_POST['semester'] ?? '1')) ?>"></label>
            <label>Credits <input type="number" name="credits" min="1" max="10" required value="<?= e((string) ($edit['credits'] ?? $_POST['credits'] ?? '4')) ?>"></label>
        </div>
        <button type="submit">Save</button>
        <?php if ($edit): ?><a class="btn btn-secondary" href="<?= e(src_url('admin/subjects.php')) ?>">Cancel</a><?php endif; ?>
    </form>
</div>
<div class="card">
    <h2>Subjects</h2>
    <table>
        <thead><tr><th data-sort>Course</th><th data-sort>Code</th><th data-sort>Name</th><th>Sem</th><th>Credits</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($list as $row): ?>
            <tr>
                <td><?= e($row['course_code']) ?></td>
                <td><?= e($row['subject_code']) ?></td>
                <td><?= e($row['subject_name']) ?></td>
                <td><?= (int) $row['semester'] ?></td>
                <td><?= (int) $row['credits'] ?></td>
                <td><a class="btn btn-small btn-outline" href="?id=<?= (int) $row['subject_id'] ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$list): ?>
            <tr class="empty-row"><td colspan="6">No subjects have been added yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
