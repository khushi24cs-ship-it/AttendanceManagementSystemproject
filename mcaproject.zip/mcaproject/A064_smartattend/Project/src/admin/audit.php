<?php
require_once __DIR__ . '/../functions.php';
require_role('Admin');
$pdo = get_pdo();
$logs = $pdo->query(
    'SELECT a.audit_id, a.old_status, a.new_status, a.reason, a.changed_at,
            u.name AS changed_by_name, st.roll_no, su.name AS student_name,
            sub.subject_code, sess.session_date
     FROM attendance_audit_logs a
     JOIN users u ON u.user_id = a.changed_by
     JOIN attendance_records r ON r.attendance_id = a.attendance_id
     JOIN students st ON st.student_id = r.student_id
     JOIN users su ON su.user_id = st.user_id
     JOIN attendance_sessions sess ON sess.session_id = r.session_id
     JOIN class_subjects cs ON cs.class_subject_id = sess.class_subject_id
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     ORDER BY a.changed_at DESC'
)->fetchAll();

$pageTitle = 'Attendance Audit Logs';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2>Correction history</h2>
    <p class="muted">Each attendance change stores the previous status, new status, reason, user, and timestamp.</p>
    <?= table_search('Search corrections') ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th data-sort>When</th>
                <th data-sort>Student</th>
                <th data-sort>Subject</th>
                <th data-sort>Date</th>
                <th>Old</th>
                <th>New</th>
                <th data-sort>By</th>
                <th>Reason</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($logs as $row): ?>
            <tr>
                <td><?= e(date('d M Y H:i', strtotime($row['changed_at']))) ?></td>
                <td><code><?= e($row['roll_no']) ?></code><br><span class="text-sm"><?= e($row['student_name']) ?></span></td>
                <td><?= e($row['subject_code']) ?></td>
                <td><?= e(date('d M Y', strtotime($row['session_date']))) ?></td>
                <td><span class="badge badge-<?= e($row['old_status']) ?>"><?= e($row['old_status']) ?></span></td>
                <td><span class="badge badge-<?= e($row['new_status']) ?>"><?= e($row['new_status']) ?></span></td>
                <td><?= e($row['changed_by_name']) ?></td>
                <td><?= e($row['reason']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$logs): ?>
            <tr class="empty-row"><td colspan="8">No corrections have been recorded yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
