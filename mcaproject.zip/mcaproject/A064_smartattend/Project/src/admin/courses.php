<?php
require_once __DIR__ . '/../functions.php';
require_role('Admin');
$pdo = get_pdo();
$errors = [];
$editId = get_int('id');
$edit = null;
if ($editId) {
    $stmt = $pdo->prepare('SELECT * FROM courses WHERE course_id = ?');
    $stmt->execute([$editId]);
    $edit = $stmt->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $id = post_int('course_id');
    $code = post_str('course_code');
    $name = post_str('course_name');
    $years = post_int('duration_years');
    if ($code === '' || $name === '' || $years < 1) {
        $errors[] = 'Course code, name, and duration are required.';
    }
    $dup = $pdo->prepare('SELECT course_id FROM courses WHERE course_code = ? AND course_id <> ?');
    $dup->execute([$code, $id]);
    if ($dup->fetch()) {
        $errors[] = 'Course code already exists.';
    }
    if (!$errors) {
        if ($id) {
            $pdo->prepare('UPDATE courses SET course_code = ?, course_name = ?, duration_years = ? WHERE course_id = ?')
                ->execute([$code, $name, $years, $id]);
            flash_set('success', 'Course updated.');
        } else {
            $pdo->prepare('INSERT INTO courses (course_code, course_name, duration_years) VALUES (?, ?, ?)')
                ->execute([$code, $name, $years]);
            flash_set('success', 'Course added.');
        }
        redirect('admin/courses.php');
    }
}

$list = $pdo->query('SELECT * FROM courses ORDER BY course_code')->fetchAll();
$pageTitle = 'Manage Courses';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2><?= $edit ? 'Edit course' : 'Add course' ?></h2>
    <?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="course_id" value="<?= $edit ? (int) $edit['course_id'] : 0 ?>">
        <div class="form-row">
            <label>Code <input type="text" name="course_code" required value="<?= e($edit['course_code'] ?? $_POST['course_code'] ?? '') ?>"></label>
            <label>Name <input type="text" name="course_name" required value="<?= e($edit['course_name'] ?? $_POST['course_name'] ?? '') ?>"></label>
            <label>Duration (years) <input type="number" name="duration_years" min="1" max="10" required value="<?= e((string) ($edit['duration_years'] ?? $_POST['duration_years'] ?? '2')) ?>"></label>
        </div>
        <button type="submit">Save</button>
        <?php if ($edit): ?><a class="btn btn-secondary" href="<?= e(src_url('admin/courses.php')) ?>">Cancel</a><?php endif; ?>
    </form>
</div>
<div class="card">
    <h2>Courses</h2>
    <table>
        <thead><tr><th data-sort>Code</th><th data-sort>Name</th><th>Years</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($list as $row): ?>
            <tr>
                <td><?= e($row['course_code']) ?></td>
                <td><?= e($row['course_name']) ?></td>
                <td><?= (int) $row['duration_years'] ?></td>
                <td><a class="btn btn-small btn-outline" href="?id=<?= (int) $row['course_id'] ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$list): ?>
            <tr class="empty-row"><td colspan="4">No courses have been added yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
