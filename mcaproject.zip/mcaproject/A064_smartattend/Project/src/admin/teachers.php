<?php
require_once __DIR__ . '/../functions.php';
require_role('Admin');
$pdo = get_pdo();
$errors = [];
$editId = get_int('id');
$edit = null;

if ($editId) {
    $stmt = $pdo->prepare('SELECT t.*, u.name, u.email FROM teachers t JOIN users u ON u.user_id = t.user_id WHERE t.teacher_id = ?');
    $stmt->execute([$editId]);
    $edit = $stmt->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = post_str('action');
    if ($action === 'deactivate') {
        $tid = post_int('teacher_id');
        $stmt = $pdo->prepare('SELECT user_id FROM teachers WHERE teacher_id = ?');
        $stmt->execute([$tid]);
        $uid = $stmt->fetchColumn();
        if ($uid) {
            $pdo->prepare('UPDATE users SET is_active = 0 WHERE user_id = ?')->execute([$uid]);
            flash_set('success', 'Teacher account deactivated. Assignments and attendance history were kept.');
        }
        redirect('admin/teachers.php');
    }

    $name = post_str('name');
    $email = post_str('email');
    $emp = post_str('employee_id');
    $dept = post_str('department');
    $desig = post_str('designation');
    $password = (string) ($_POST['password'] ?? '');
    $teacherId = post_int('teacher_id');

    if ($name === '' || $email === '' || $emp === '' || $dept === '' || $desig === '') {
        $errors[] = 'All teacher fields are required.';
    }
    if (!is_valid_email($email)) {
        $errors[] = 'Enter a valid email address.';
    }
    $userId = $teacherId ? (int) ($edit['user_id'] ?? 0) : 0;
    $emailStmt = $pdo->prepare('SELECT user_id FROM users WHERE email = ? AND user_id <> ?');
    $emailStmt->execute([$email, $userId]);
    if ($emailStmt->fetch()) {
        $errors[] = 'This email is already registered.';
    }
    $empStmt = $pdo->prepare('SELECT teacher_id FROM teachers WHERE employee_id = ? AND teacher_id <> ?');
    $empStmt->execute([$emp, $teacherId]);
    if ($empStmt->fetch()) {
        $errors[] = 'This employee ID is already in use.';
    }
    if (!$teacherId && strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters for a new teacher.';
    }

    if (!$errors) {
        try {
            if ($teacherId && $edit) {
                $pdo->beginTransaction();
                $pdo->prepare('UPDATE users SET name = ?, email = ? WHERE user_id = ?')->execute([$name, $email, $edit['user_id']]);
                $pdo->prepare('UPDATE teachers SET employee_id = ?, department = ?, designation = ? WHERE teacher_id = ?')
                    ->execute([$emp, $dept, $desig, $teacherId]);
                if ($password !== '') {
                    $pdo->prepare('UPDATE users SET password_hash = ? WHERE user_id = ?')
                        ->execute([password_hash($password, PASSWORD_DEFAULT), $edit['user_id']]);
                }
                $pdo->commit();
                flash_set('success', 'Teacher details updated.');
            } else {
                $pdo->beginTransaction();
                $pdo->prepare('INSERT INTO users (name, email, password_hash, role, is_active) VALUES (?, ?, ?, ?, 1)')
                    ->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), 'Teacher']);
                $uid = (int) $pdo->lastInsertId();
                $pdo->prepare('INSERT INTO teachers (user_id, employee_id, department, designation) VALUES (?, ?, ?, ?)')
                    ->execute([$uid, $emp, $dept, $desig]);
                $pdo->commit();
                flash_set('success', 'Teacher account created.');
            }
            redirect('admin/teachers.php');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'Could not save the teacher. Check for duplicate values.';
        }
    }
}

$list = $pdo->query(
    'SELECT t.teacher_id, t.employee_id, t.department, t.designation, u.name, u.email, u.is_active
     FROM teachers t JOIN users u ON u.user_id = t.user_id ORDER BY t.employee_id'
)->fetchAll();

$pageTitle = 'Manage Teachers';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2><?= $edit ? 'Edit teacher' : 'Add teacher' ?></h2>
    <?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="teacher_id" value="<?= $edit ? (int) $edit['teacher_id'] : 0 ?>">
        <div class="form-row">
            <label>Name <input type="text" name="name" required value="<?= e($edit['name'] ?? $_POST['name'] ?? '') ?>"></label>
            <label>Email <input type="email" name="email" required value="<?= e($edit['email'] ?? $_POST['email'] ?? '') ?>"></label>
            <label>Employee ID <input type="text" name="employee_id" required value="<?= e($edit['employee_id'] ?? $_POST['employee_id'] ?? '') ?>"></label>
            <label>Department <input type="text" name="department" required value="<?= e($edit['department'] ?? $_POST['department'] ?? '') ?>"></label>
            <label>Designation <input type="text" name="designation" required value="<?= e($edit['designation'] ?? $_POST['designation'] ?? '') ?>"></label>
            <label><?= $edit ? 'New password (optional)' : 'Password' ?>
                <input type="password" name="password" <?= $edit ? '' : 'required minlength="6"' ?>>
            </label>
        </div>
        <button type="submit"><?= $edit ? 'Update teacher' : 'Add teacher' ?></button>
        <?php if ($edit): ?><a class="btn btn-secondary" href="<?= e(src_url('admin/teachers.php')) ?>">Cancel</a><?php endif; ?>
    </form>
</div>
<div class="card">
    <h2>Teacher accounts</h2>
    <?= table_search('Search teachers') ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th data-sort>Emp ID</th>
                <th data-sort>Name</th>
                <th data-sort>Email</th>
                <th data-sort>Department</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($list as $row): ?>
            <tr>
                <td><?= e($row['employee_id']) ?></td>
                <td><?= e($row['name']) ?></td>
                <td><?= e($row['email']) ?></td>
                <td><?= e($row['department'] . ' / ' . $row['designation']) ?></td>
                <td><span class="badge badge-<?= (int) $row['is_active'] ? 'Active' : 'Inactive' ?>"><?= (int) $row['is_active'] ? 'Active' : 'Inactive' ?></span></td>
                <td>
                    <a class="btn btn-small btn-outline" href="?id=<?= (int) $row['teacher_id'] ?>">Edit</a>
                    <?php if ((int) $row['is_active']): ?>
                    <form method="post" style="display:inline">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="deactivate">
                        <input type="hidden" name="teacher_id" value="<?= (int) $row['teacher_id'] ?>">
                        <button class="btn btn-small btn-danger" data-confirm="Deactivate this teacher?">Deactivate</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$list): ?>
            <tr class="empty-row"><td colspan="6">No teachers have been added yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
