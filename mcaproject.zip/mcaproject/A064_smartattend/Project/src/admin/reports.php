<?php
require_once __DIR__ . '/../functions.php';
require_role('Admin');
$pdo = get_pdo();
$csId = get_int('class_subject_id');

$assignments = $pdo->query(
    'SELECT cs.class_subject_id, sub.subject_code, sub.subject_name, c.semester, c.division, co.course_code
     FROM class_subjects cs
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN classes c ON c.class_id = cs.class_id
     JOIN courses co ON co.course_id = c.course_id
     ORDER BY sub.subject_code'
)->fetchAll();

$sessions = [];
$rows = [];
$below = [];
$summary = null;
if ($csId) {
    $sess = $pdo->prepare(
        'SELECT session_id, session_date, start_time, end_time, status
         FROM attendance_sessions WHERE class_subject_id = ? ORDER BY session_date'
    );
    $sess->execute([$csId]);
    $sessions = $sess->fetchAll();

    $rows = attendance_stats_map($pdo, $csId);
    foreach ($rows as $student) {
        if ($student['stats']['percent'] !== null && $student['stats']['percent'] < MIN_ATTENDANCE_PERCENT) {
            $below[] = $student;
        }
    }
    $eligibleSessions = 0;
    foreach ($sessions as $s) {
        if ($s['status'] === 'FINALIZED') {
            $eligibleSessions++;
        }
    }
    $summary = [
        'students' => count($rows),
        'eligible_sessions' => $eligibleSessions,
        'below' => count($below),
    ];
}

$pageTitle = 'Attendance Reports';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2>Select class-subject</h2>
    <form method="get">
        <label for="class_subject_id">Assignment
            <select id="class_subject_id" name="class_subject_id" required>
                <option value="">Select</option>
                <?php foreach ($assignments as $a): ?>
                    <option value="<?= (int) $a['class_subject_id'] ?>" <?= $csId === (int) $a['class_subject_id'] ? 'selected' : '' ?>>
                        <?= e($a['course_code'] . ' Sem ' . $a['semester'] . ' / ' . $a['subject_code'] . ' - ' . $a['subject_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <button type="submit">View report</button>
    </form>
</div>
<?php if ($csId): ?>
<div class="grid">
    <div class="card"><h3>Students</h3><div class="stat"><?= (int) $summary['students'] ?></div></div>
    <div class="card"><h3>Eligible sessions</h3><div class="stat"><?= (int) $summary['eligible_sessions'] ?></div></div>
    <div class="card"><h3>Below 80%</h3><div class="stat"><?= (int) $summary['below'] ?></div></div>
</div>
<div class="card">
    <h2>Subject-wise student attendance</h2>
    <p class="muted">PRESENT and LATE count as attended. Missing marks on finalized sessions remain in the total and count as not attended.</p>
    <?= table_search('Search by roll or name') ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th data-sort>Roll</th>
                <th data-sort>Name</th>
                <th data-sort>Attended</th>
                <th data-sort>Absences</th>
                <th data-sort>Eligible sessions</th>
                <th data-sort>Percentage</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $row): $st = $row['stats']; ?>
            <tr>
                <td><code><?= e($row['roll_no']) ?></code></td>
                <td><?= e($row['name']) ?></td>
                <td><?= $st['total'] ? (int) $st['attended'] : '-' ?></td>
                <td><?= $st['total'] ? (int) $st['absent'] : '-' ?></td>
                <td><?= $st['total'] ? (int) $st['total'] : '-' ?></td>
                <td><?= e(format_percent($st['percent'])) ?></td>
                <td>
                    <?php if ($st['percent'] === null): ?>
                        <span class="badge badge-none">No attendance data</span>
                    <?php else: ?>
                        <span class="badge <?= $st['eligible'] ? 'badge-Eligible' : 'badge-Below' ?>"><?= e($st['label']) ?></span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?>
            <tr class="empty-row"><td colspan="7">No students are enrolled in this class.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<div class="card">
    <h2>Students below 80%</h2>
    <?php if (!$below): ?>
        <p>No students are below 80% for this subject, or there is no attendance data yet.</p>
    <?php else: ?>
        <table>
            <thead><tr><th>Roll</th><th>Name</th><th>Attended / Total</th><th>%</th></tr></thead>
            <tbody>
            <?php foreach ($below as $row): ?>
                <tr>
                    <td><code><?= e($row['roll_no']) ?></code></td>
                    <td><?= e($row['name']) ?></td>
                    <td><?= (int) $row['stats']['attended'] . ' / ' . (int) $row['stats']['total'] ?></td>
                    <td><?= e(format_percent($row['stats']['percent'])) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<div class="card">
    <h2>Attendance sessions</h2>
    <table>
        <thead><tr><th>Date</th><th>Time</th><th>Status</th><th>Counts in %</th></tr></thead>
        <tbody>
        <?php foreach ($sessions as $s): ?>
            <tr>
                <td><?= e($s['session_date']) ?></td>
                <td><?= e(substr($s['start_time'], 0, 5) . ' - ' . substr($s['end_time'], 0, 5)) ?></td>
                <td><span class="badge badge-<?= e($s['status']) ?>"><?= e($s['status']) ?></span></td>
                <td><?= $s['status'] === 'FINALIZED' ? 'Yes' : 'No' ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$sessions): ?>
            <tr class="empty-row"><td colspan="4">No sessions found for this assignment.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
