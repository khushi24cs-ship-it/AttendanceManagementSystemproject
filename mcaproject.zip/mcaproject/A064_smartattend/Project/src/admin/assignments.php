<?php
require_once __DIR__ . '/../functions.php';
require_role('Admin');
$pdo = get_pdo();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $classId = post_int('class_id');
    $subjectId = post_int('subject_id');
    $teacherId = post_int('teacher_id');
    $id = post_int('class_subject_id');

    $class = $pdo->prepare('SELECT class_id, course_id, semester FROM classes WHERE class_id = ?');
    $class->execute([$classId]);
    $classRow = $class->fetch();
    $sub = $pdo->prepare('SELECT subject_id, course_id, semester FROM subjects WHERE subject_id = ?');
    $sub->execute([$subjectId]);
    $subRow = $sub->fetch();
    $tea = $pdo->prepare('SELECT teacher_id FROM teachers t JOIN users u ON u.user_id = t.user_id WHERE t.teacher_id = ? AND u.is_active = 1');
    $tea->execute([$teacherId]);

    if (!$classRow || !$subRow || !$tea->fetch()) {
        $errors[] = 'Class, subject, and an active teacher are required.';
    } elseif ((int) $classRow['course_id'] !== (int) $subRow['course_id']) {
        $errors[] = 'The subject does not belong to the same course as the class.';
    } elseif ((int) $classRow['semester'] !== (int) $subRow['semester']) {
        $errors[] = 'The subject semester must match the class semester.';
    } else {
        $dup = $pdo->prepare('SELECT class_subject_id FROM class_subjects WHERE class_id = ? AND subject_id = ? AND class_subject_id <> ?');
        $dup->execute([$classId, $subjectId, $id]);
        if ($dup->fetch()) {
            $errors[] = 'This subject is already assigned to the class.';
        }
    }

    if (!$errors) {
        if ($id) {
            $pdo->prepare('UPDATE class_subjects SET class_id = ?, subject_id = ?, teacher_id = ? WHERE class_subject_id = ?')
                ->execute([$classId, $subjectId, $teacherId, $id]);
            flash_set('success', 'Assignment updated.');
        } else {
            $pdo->prepare('INSERT INTO class_subjects (class_id, subject_id, teacher_id) VALUES (?, ?, ?)')
                ->execute([$classId, $subjectId, $teacherId]);
            flash_set('success', 'Teacher assigned to the class subject.');
        }
        redirect('admin/assignments.php');
    }
}

$editId = get_int('id');
$edit = null;
if ($editId) {
    $stmt = $pdo->prepare('SELECT * FROM class_subjects WHERE class_subject_id = ?');
    $stmt->execute([$editId]);
    $edit = $stmt->fetch() ?: null;
}

$classes = $pdo->query(
    'SELECT c.class_id, c.semester, c.division, c.academic_year, co.course_code
     FROM classes c JOIN courses co ON co.course_id = c.course_id ORDER BY co.course_code'
)->fetchAll();
$subjects = $pdo->query(
    'SELECT s.subject_id, s.subject_code, s.subject_name, s.semester, co.course_code
     FROM subjects s JOIN courses co ON co.course_id = s.course_id ORDER BY s.subject_code'
)->fetchAll();
$teachers = $pdo->query(
    'SELECT t.teacher_id, t.employee_id, u.name FROM teachers t JOIN users u ON u.user_id = t.user_id WHERE u.is_active = 1 ORDER BY u.name'
)->fetchAll();
$list = $pdo->query(
    'SELECT cs.class_subject_id, sub.subject_code, sub.subject_name, u.name AS teacher_name,
            c.semester, c.division, c.academic_year, co.course_code
     FROM class_subjects cs
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN teachers t ON t.teacher_id = cs.teacher_id
     JOIN users u ON u.user_id = t.user_id
     JOIN classes c ON c.class_id = cs.class_id
     JOIN courses co ON co.course_id = c.course_id
     ORDER BY co.course_code, sub.subject_code'
)->fetchAll();

$pageTitle = 'Class-Subject Assignments';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2><?= $edit ? 'Edit assignment' : 'Assign subject and teacher' ?></h2>
    <?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="class_subject_id" value="<?= $edit ? (int) $edit['class_subject_id'] : 0 ?>">
        <div class="form-row">
            <label>Class
                <select name="class_id" required>
                    <option value="">Select</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?= (int) $c['class_id'] ?>" <?= ((int) ($edit['class_id'] ?? $_POST['class_id'] ?? 0) === (int) $c['class_id']) ? 'selected' : '' ?>>
                            <?= e($c['course_code'] . ' Sem ' . $c['semester'] . ' Div ' . $c['division']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Subject
                <select name="subject_id" required>
                    <option value="">Select</option>
                    <?php foreach ($subjects as $s): ?>
                        <option value="<?= (int) $s['subject_id'] ?>" <?= ((int) ($edit['subject_id'] ?? $_POST['subject_id'] ?? 0) === (int) $s['subject_id']) ? 'selected' : '' ?>>
                            <?= e($s['course_code'] . ' ' . $s['subject_code'] . ' - ' . $s['subject_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Teacher
                <select name="teacher_id" required>
                    <option value="">Select</option>
                    <?php foreach ($teachers as $t): ?>
                        <option value="<?= (int) $t['teacher_id'] ?>" <?= ((int) ($edit['teacher_id'] ?? $_POST['teacher_id'] ?? 0) === (int) $t['teacher_id']) ? 'selected' : '' ?>>
                            <?= e($t['name'] . ' (' . $t['employee_id'] . ')') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
        <button type="submit">Save assignment</button>
        <?php if ($edit): ?><a class="btn btn-secondary" href="<?= e(src_url('admin/assignments.php')) ?>">Cancel</a><?php endif; ?>
    </form>
</div>
<div class="card">
    <h2>Current assignments</h2>
    <table>
        <thead><tr><th data-sort>Class</th><th data-sort>Subject</th><th data-sort>Teacher</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($list as $row): ?>
            <tr>
                <td><?= e($row['course_code'] . ' Sem ' . $row['semester'] . '-' . $row['division']) ?></td>
                <td><?= e($row['subject_code'] . ' - ' . $row['subject_name']) ?></td>
                <td><?= e($row['teacher_name']) ?></td>
                <td><a class="btn btn-small btn-outline" href="?id=<?= (int) $row['class_subject_id'] ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$list): ?>
            <tr class="empty-row"><td colspan="4">No class-subject assignments have been created yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
