<?php
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function src_url(string $path): string
{
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $markers = ['/admin/', '/teacher/', '/student/'];
    $base = null;
    foreach ($markers as $marker) {
        $pos = strpos($script, $marker);
        if ($pos !== false) {
            $base = substr($script, 0, $pos);
            break;
        }
    }
    if ($base === null) {
        $base = rtrim(str_replace('\\', '/', dirname($script)), '/');
    }
    return $base . '/' . ltrim($path, '/');
}

function current_script(): string
{
    return str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
}

function nav_active(string $path): string
{
    $script = current_script();
    $needle = '/' . ltrim($path, '/');
    $match = substr($script, -strlen($needle)) === $needle;
    if (!$match) {
        $aliases = [
            'teacher/sessions.php' => ['teacher/edit.php'],
        ];
        foreach ($aliases[$path] ?? [] as $alias) {
            $a = '/' . $alias;
            if (substr($script, -strlen($a)) === $a) {
                $match = true;
                break;
            }
        }
    }
    return $match ? ' aria-current="page" class="is-active"' : '';
}

function redirect(string $path): void
{
    header('Location: ' . src_url($path));
    exit;
}

function flash_set(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function flash_get(): ?array
{
    if (empty($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function require_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(400);
        exit('Invalid request. Please refresh the page and try again.');
    }
}

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    return [
        'user_id' => (int) $_SESSION['user_id'],
        'name' => $_SESSION['name'] ?? '',
        'role' => $_SESSION['role'] ?? '',
        'student_id' => isset($_SESSION['student_id']) ? (int) $_SESSION['student_id'] : null,
        'teacher_id' => isset($_SESSION['teacher_id']) ? (int) $_SESSION['teacher_id'] : null,
    ];
}

function require_login(): array
{
    $user = current_user();
    if (!$user) {
        redirect('index.php');
    }
    return $user;
}

function require_role(string $role): array
{
    $user = require_login();
    if ($user['role'] !== $role) {
        http_response_code(403);
        exit('You are not allowed to open this page.');
    }
    if ($role === 'Student' && empty($user['student_id'])) {
        http_response_code(403);
        exit('This student account has no class profile. Contact the administrator.');
    }
    if ($role === 'Teacher' && empty($user['teacher_id'])) {
        http_response_code(403);
        exit('This teacher account has no staff profile. Contact the administrator.');
    }
    return $user;
}

function login_user(array $row): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $row['user_id'];
    $_SESSION['name'] = $row['name'];
    $_SESSION['role'] = $row['role'];
    unset($_SESSION['student_id'], $_SESSION['teacher_id']);

    $pdo = get_pdo();
    if ($row['role'] === 'Student') {
        $stmt = $pdo->prepare('SELECT student_id FROM students WHERE user_id = ?');
        $stmt->execute([$row['user_id']]);
        $sid = $stmt->fetchColumn();
        if ($sid) {
            $_SESSION['student_id'] = (int) $sid;
        }
    }
    if ($row['role'] === 'Teacher') {
        $stmt = $pdo->prepare('SELECT teacher_id FROM teachers WHERE user_id = ?');
        $stmt->execute([$row['user_id']]);
        $tid = $stmt->fetchColumn();
        if ($tid) {
            $_SESSION['teacher_id'] = (int) $tid;
        }
    }
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function is_valid_email(string $email): bool
{
    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

function is_valid_status(string $status): bool
{
    return in_array($status, ['PRESENT', 'ABSENT', 'LATE'], true);
}

function is_valid_date(string $date): bool
{
    $dt = DateTime::createFromFormat('Y-m-d', $date);
    return $dt !== false && $dt->format('Y-m-d') === $date;
}

function is_valid_time(string $time): bool
{
    return (bool) preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $time);
}

/**
 * Build percentage stats from eligible-session counts.
 * PRESENT and LATE count as attended. Eligibility uses the unrounded value.
 * Exactly 80% meets the requirement.
 */
function attendance_from_counts(int $total, int $attended): array
{
    if ($total === 0) {
        return [
            'total' => 0,
            'attended' => 0,
            'absent' => 0,
            'percent' => null,
            'eligible' => null,
            'label' => 'No attendance data',
        ];
    }

    $percent = ($attended / $total) * 100;
    $meets = $percent >= MIN_ATTENDANCE_PERCENT;

    return [
        'total' => $total,
        'attended' => $attended,
        'absent' => $total - $attended,
        'percent' => $percent,
        'eligible' => $meets,
        'label' => $meets ? 'Eligible' : 'Below 80%',
    ];
}

/**
 * Subject-wise attendance for one student in one class-subject.
 * Only FINALIZED sessions are eligible. CANCELLED and DRAFT are excluded.
 * A missing record still counts in the denominator and is treated as not attended.
 */
function attendance_stats(PDO $pdo, int $studentId, int $classSubjectId): array
{
    $stmt = $pdo->prepare(
        'SELECT
            COUNT(s.session_id) AS total,
            COALESCE(SUM(CASE WHEN r.attendance_status IN (\'PRESENT\', \'LATE\') THEN 1 ELSE 0 END), 0) AS attended
         FROM attendance_sessions s
         LEFT JOIN attendance_records r
            ON r.session_id = s.session_id AND r.student_id = ?
         WHERE s.class_subject_id = ?
           AND s.status = \'FINALIZED\''
    );
    $stmt->execute([$studentId, $classSubjectId]);
    $row = $stmt->fetch() ?: ['total' => 0, 'attended' => 0];
    return attendance_from_counts((int) $row['total'], (int) $row['attended']);
}

/**
 * Subject-wise stats for one student in a single query.
 * Missing marks on FINALIZED sessions stay in the denominator.
 */
function attendance_stats_for_student(PDO $pdo, int $studentId): array
{
    $stmt = $pdo->prepare(
        'SELECT cs.class_subject_id,
                COUNT(sess.session_id) AS total,
                COALESCE(SUM(CASE WHEN r.attendance_status IN (\'PRESENT\', \'LATE\') THEN 1 ELSE 0 END), 0) AS attended
         FROM students st
         JOIN class_subjects cs ON cs.class_id = st.class_id
         LEFT JOIN attendance_sessions sess
            ON sess.class_subject_id = cs.class_subject_id AND sess.status = \'FINALIZED\'
         LEFT JOIN attendance_records r
            ON r.session_id = sess.session_id AND r.student_id = st.student_id
         WHERE st.student_id = ?
         GROUP BY cs.class_subject_id'
    );
    $stmt->execute([$studentId]);
    $out = [];
    foreach ($stmt->fetchAll() as $row) {
        $out[(int) $row['class_subject_id']] = attendance_from_counts((int) $row['total'], (int) $row['attended']);
    }
    return $out;
}

/**
 * One query for every student in a class-subject. Missing marks remain in the denominator.
 */
function attendance_stats_map(PDO $pdo, int $classSubjectId): array
{
    $totalStmt = $pdo->prepare(
        'SELECT COUNT(*) FROM attendance_sessions WHERE class_subject_id = ? AND status = \'FINALIZED\''
    );
    $totalStmt->execute([$classSubjectId]);
    $total = (int) $totalStmt->fetchColumn();

    $stmt = $pdo->prepare(
        'SELECT s.student_id, s.roll_no, s.status AS student_status, u.name,
                COALESCE(SUM(CASE WHEN r.attendance_status IN (\'PRESENT\', \'LATE\') THEN 1 ELSE 0 END), 0) AS attended
         FROM class_subjects cs
         JOIN students s ON s.class_id = cs.class_id
         JOIN users u ON u.user_id = s.user_id
         LEFT JOIN attendance_sessions sess
            ON sess.class_subject_id = cs.class_subject_id AND sess.status = \'FINALIZED\'
         LEFT JOIN attendance_records r
            ON r.session_id = sess.session_id AND r.student_id = s.student_id
         WHERE cs.class_subject_id = ?
         GROUP BY s.student_id, s.roll_no, s.status, u.name
         ORDER BY s.roll_no'
    );
    $stmt->execute([$classSubjectId]);

    $out = [];
    foreach ($stmt->fetchAll() as $row) {
        $stats = attendance_from_counts($total, (int) $row['attended']);
        $row['stats'] = $stats;
        $out[] = $row;
    }
    return $out;
}

/**
 * Students below 80% per assigned class-subject. Subjects with no FINALIZED
 * sessions are not counted as below (they have no attendance data).
 */
function below_counts_for_teacher(PDO $pdo, int $teacherId): array
{
    $min = (int) MIN_ATTENDANCE_PERCENT;
    $stmt = $pdo->prepare(
        "SELECT cs.class_subject_id,
                SUM(CASE
                    WHEN COALESCE(totals.total_sessions, 0) = 0 THEN 0
                    WHEN (COALESCE(att.attended, 0) / totals.total_sessions) * 100 < {$min} THEN 1
                    ELSE 0
                END) AS below_count
         FROM class_subjects cs
         JOIN students s ON s.class_id = cs.class_id
         LEFT JOIN (
            SELECT class_subject_id, COUNT(*) AS total_sessions
            FROM attendance_sessions
            WHERE status = 'FINALIZED'
            GROUP BY class_subject_id
         ) totals ON totals.class_subject_id = cs.class_subject_id
         LEFT JOIN (
            SELECT sess.class_subject_id, r.student_id,
                   SUM(CASE WHEN r.attendance_status IN ('PRESENT', 'LATE') THEN 1 ELSE 0 END) AS attended
            FROM attendance_records r
            JOIN attendance_sessions sess ON sess.session_id = r.session_id AND sess.status = 'FINALIZED'
            GROUP BY sess.class_subject_id, r.student_id
         ) att ON att.class_subject_id = cs.class_subject_id AND att.student_id = s.student_id
         WHERE cs.teacher_id = ?
         GROUP BY cs.class_subject_id"
    );
    $stmt->execute([$teacherId]);
    $out = [];
    foreach ($stmt->fetchAll() as $row) {
        $out[(int) $row['class_subject_id']] = (int) $row['below_count'];
    }
    return $out;
}

function format_percent(?float $percent): string
{
    if ($percent === null) {
        return 'No attendance data';
    }
    return number_format($percent, 2) . '%';
}

function fetch_teacher_assignment(PDO $pdo, int $teacherId, int $classSubjectId): ?array
{
    $stmt = $pdo->prepare(
        'SELECT cs.class_subject_id, cs.class_id, cs.subject_id, cs.teacher_id,
                sub.subject_code, sub.subject_name,
                c.semester, c.division, c.academic_year, co.course_code
         FROM class_subjects cs
         JOIN subjects sub ON sub.subject_id = cs.subject_id
         JOIN classes c ON c.class_id = cs.class_id
         JOIN courses co ON co.course_id = c.course_id
         WHERE cs.class_subject_id = ? AND cs.teacher_id = ?'
    );
    $stmt->execute([$classSubjectId, $teacherId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function class_students(PDO $pdo, int $classId): array
{
    $stmt = $pdo->prepare(
        'SELECT s.student_id, s.roll_no, s.status, u.name, u.email, u.is_active
         FROM students s
         JOIN users u ON u.user_id = s.user_id
         WHERE s.class_id = ?
         ORDER BY s.roll_no'
    );
    $stmt->execute([$classId]);
    return $stmt->fetchAll();
}

function correct_attendance(PDO $pdo, int $attendanceId, string $newStatus, string $reason, int $changedBy, bool $ownTransaction = true): void
{
    if (!is_valid_status($newStatus)) {
        throw new InvalidArgumentException('Invalid attendance status.');
    }
    $reason = trim($reason);
    if ($reason === '') {
        throw new InvalidArgumentException('A reason is required for every attendance correction.');
    }
    if (strlen($reason) > 255) {
        throw new InvalidArgumentException('The correction reason must be 255 characters or fewer.');
    }

    if ($ownTransaction) {
        $pdo->beginTransaction();
    }
    try {
        $stmt = $pdo->prepare('SELECT attendance_id, attendance_status FROM attendance_records WHERE attendance_id = ? FOR UPDATE');
        $stmt->execute([$attendanceId]);
        $row = $stmt->fetch();
        if (!$row) {
            throw new RuntimeException('Attendance record was not found.');
        }
        $old = $row['attendance_status'];
        if ($old === $newStatus) {
            if ($ownTransaction) {
                $pdo->rollBack();
            }
            return;
        }

        $upd = $pdo->prepare('UPDATE attendance_records SET attendance_status = ? WHERE attendance_id = ?');
        $upd->execute([$newStatus, $attendanceId]);

        $log = $pdo->prepare(
            'INSERT INTO attendance_audit_logs (attendance_id, changed_by, old_status, new_status, reason)
             VALUES (?, ?, ?, ?, ?)'
        );
        $log->execute([$attendanceId, $changedBy, $old, $newStatus, $reason]);
        if ($ownTransaction) {
            $pdo->commit();
        }
    } catch (Throwable $e) {
        if ($ownTransaction && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function post_str(string $key): string
{
    return trim((string) ($_POST[$key] ?? ''));
}

function post_int(string $key): int
{
    return (int) ($_POST[$key] ?? 0);
}

function get_int(string $key): int
{
    return (int) ($_GET[$key] ?? 0);
}


function table_search(string $placeholder = 'Search this table'): string
{
    $ph = e($placeholder);
    return '<div class="table-tools">'
        . '<label class="sr-only" for="table-search">' . $ph . '</label>'
        . '<input type="search" id="table-search" class="table-search" data-table-search placeholder="' . $ph . '&hellip;">'
        . '<span class="table-count"></span>'
        . '</div>';
}
