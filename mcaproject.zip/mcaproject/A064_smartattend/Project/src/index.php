<?php
require_once __DIR__ . '/functions.php';

if (current_user()) {
    $role = $_SESSION['role'];
    if ($role === 'Admin')   redirect('admin/dashboard.php');
    if ($role === 'Teacher') redirect('teacher/dashboard.php');
    redirect('student/dashboard.php');
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $email    = post_str('email');
    $password = (string) ($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = 'Please enter both email and password.';
    } elseif (!is_valid_email($email)) {
        $error = 'Please enter a valid email address.';
    } else {
        $stmt = get_pdo()->prepare(
            'SELECT user_id, name, email, password_hash, role, is_active FROM users WHERE email = ?'
        );
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        if (!$row || !password_verify($password, $row['password_hash'])) {
            $error = 'Incorrect email or password.';
        } elseif (!(int) $row['is_active']) {
            $error = 'This account has been deactivated. Contact the administrator.';
        } else {
            login_user($row);
            if ($row['role'] === 'Admin')   redirect('admin/dashboard.php');
            if ($row['role'] === 'Teacher') redirect('teacher/dashboard.php');
            redirect('student/dashboard.php');
        }
    }
}

$pageTitle = 'Login';
require __DIR__ . '/includes/header.php';
?>
<section class="login-card">
    <p class="login-kicker">MCA academic project</p>
    <h1>Smart Attendance<br>Management System</h1>
    <p class="lede">Sign in to mark, review, and report subject-wise attendance. The eligibility rule is 80% per subject.</p>
    <?php if ($error): ?>
        <div class="alert alert-error" role="alert"><?= e($error) ?></div>
    <?php endif; ?>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <label for="email">Email address
            <input id="email" type="email" name="email" value="<?= e($email) ?>"
                   required autocomplete="username" placeholder="you@example.com">
        </label>
        <label for="password">Password
            <input id="password" type="password" name="password"
                   required minlength="6" autocomplete="current-password" placeholder="&bull;&bull;&bull;&bull;&bull;&bull;">
        </label>
        <button type="submit" style="width:100%;margin-top:0.9rem">Sign in</button>
    </form>

    <details class="demo-box">
        <summary>Demonstration accounts</summary>
        <p class="muted" style="margin-top:0.5rem">Click a button to fill the form, then click Sign in. Passwords are stored as hashes &mdash; never plaintext.</p>
        <div class="quick-fill-btns">
            <button type="button"
                    data-fill-email="admin@smartattend.local"
                    data-fill-pass="Admin@123">Admin</button>
            <button type="button"
                    data-fill-email="teacher1@smartattend.local"
                    data-fill-pass="Teacher@123">Teacher</button>
            <button type="button"
                    data-fill-email="student1@smartattend.local"
                    data-fill-pass="Student@123">Student (Aarav &mdash; 80% WT, 60% DBMS)</button>
            <button type="button"
                    data-fill-email="student2@smartattend.local"
                    data-fill-pass="Student@123">Student (Diya &mdash; 100% WT, 80% DBMS)</button>
            <button type="button"
                    data-fill-email="student6@smartattend.local"
                    data-fill-pass="Student@123">Student (Meera &mdash; no data)</button>
        </div>
        <table class="compact" style="margin-top:0.8rem">
            <thead><tr><th>Role</th><th>Email</th><th>Password</th></tr></thead>
            <tbody>
                <tr><td>Admin</td><td>admin@smartattend.local</td><td>Admin@123</td></tr>
                <tr><td>Teacher</td><td>teacher1@smartattend.local</td><td>Teacher@123</td></tr>
                <tr><td>Student (×6)</td><td>student1&ndash;6@smartattend.local</td><td>Student@123</td></tr>
            </tbody>
        </table>
    </details>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
