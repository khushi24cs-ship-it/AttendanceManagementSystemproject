<?php
require_once __DIR__ . '/../functions.php';
$user = require_role('Student');
$pdo = get_pdo();
$studentId = (int) $user['student_id'];

$stmt = $pdo->prepare(
    'SELECT cs.class_subject_id, sub.subject_code, sub.subject_name
     FROM students s
     JOIN class_subjects cs ON cs.class_id = s.class_id
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     WHERE s.student_id = ?
     ORDER BY sub.subject_code'
);
$stmt->execute([$studentId]);
$subjects = $stmt->fetchAll();
$statsMap = attendance_stats_for_student($pdo, $studentId);

$pageTitle = 'Attendance Report';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2>Subject-wise eligibility (minimum 80%)</h2>
    <p class="muted">PRESENT and LATE count as attended. ABSENT does not. Cancelled or unfinalized sessions are excluded. Eligibility is decided per subject from the actual percentage, then displayed to two decimal places. Exactly 80% is Eligible.</p>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>Subject</th><th>Attended</th><th>Absences</th><th>Eligible sessions</th><th>Percentage</th><th>Status</th></tr>
        </thead>
        <tbody>
        <?php foreach ($subjects as $sub):
            $st = $statsMap[(int) $sub['class_subject_id']] ?? attendance_from_counts(0, 0); ?>
            <tr>
                <td><strong><?= e($sub['subject_code']) ?></strong><br><span class="text-sm muted"><?= e($sub['subject_name']) ?></span></td>
                <td><?= $st['total'] ? (int) $st['attended'] : '-' ?></td>
                <td><?= $st['total'] ? (int) $st['absent'] : '-' ?></td>
                <td><?= $st['total'] ? (int) $st['total'] : '-' ?></td>
                <td class="<?= $st['percent'] === null ? '' : ($st['percent'] >= 80 ? 'pct-ok' : ($st['percent'] >= 60 ? 'pct-warn' : 'pct-bad')) ?>"><?= e(format_percent($st['percent'])) ?>
                    <?php if ($st['percent'] !== null): $pct = min(100, max(0, (float) $st['percent'])); ?>
                    <div class="mini-bar"><div class="mini-bar-fill" style="width:<?= $pct ?>%;background:<?= $st['percent'] >= 80 ? 'var(--ok)' : ($st['percent'] >= 60 ? 'var(--warn)' : 'var(--danger)') ?>"></div></div>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($st['percent'] === null): ?>
                        <span class="badge badge-none">No attendance data</span>
                    <?php else: ?>
                        <span class="badge <?= $st['eligible'] ? 'badge-Eligible' : 'badge-Below' ?>"><?= e($st['label']) ?></span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$subjects): ?>
            <tr class="empty-row"><td colspan="6">No subjects are assigned to your class.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
