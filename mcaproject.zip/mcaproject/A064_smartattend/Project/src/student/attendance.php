<?php
require_once __DIR__ . '/../functions.php';
$user = require_role('Student');
$pdo = get_pdo();
$studentId = (int) $user['student_id'];
$filter = trim((string) ($_GET['subject'] ?? ''));

$subjects = $pdo->prepare(
    'SELECT DISTINCT sub.subject_code, sub.subject_name
     FROM students st
     JOIN class_subjects cs ON cs.class_id = st.class_id
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     WHERE st.student_id = ?
     ORDER BY sub.subject_code'
);
$subjects->execute([$studentId]);
$subjectList = $subjects->fetchAll();
$allowedCodes = array_column($subjectList, 'subject_code');
if ($filter !== '' && !in_array($filter, $allowedCodes, true)) {
    $filter = '';
}

$stmt = $pdo->prepare(
    'SELECT sess.session_id, sess.session_date, sess.start_time, sess.end_time, sess.status,
            sub.subject_code, sub.subject_name, r.attendance_status
     FROM students st
     JOIN class_subjects cs ON cs.class_id = st.class_id
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN attendance_sessions sess ON sess.class_subject_id = cs.class_subject_id
     LEFT JOIN attendance_records r ON r.session_id = sess.session_id AND r.student_id = st.student_id
     WHERE st.student_id = ?
     ORDER BY sub.subject_code, sess.session_date'
);
$stmt->execute([$studentId]);
$rows = $stmt->fetchAll();
if ($filter !== '') {
    $rows = array_values(array_filter($rows, static function ($row) use ($filter) {
        return $row['subject_code'] === $filter;
    }));
}

$pageTitle = 'My Attendance';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2>Session history</h2>
    <p class="muted">Only your own records are shown. Cancelled and unfinalized sessions are listed for information but are not counted in the 80% calculation. A finalized session with no mark still counts as not attended.</p>
    <form method="get" class="form-row">
        <label for="subject">Subject
            <select id="subject" name="subject">
                <option value="">All subjects</option>
                <?php foreach ($subjectList as $sub): ?>
                    <option value="<?= e($sub['subject_code']) ?>" <?= $filter === $sub['subject_code'] ? 'selected' : '' ?>>
                        <?= e($sub['subject_code'] . ' - ' . $sub['subject_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <div><button type="submit">Filter</button></div>
    </form>
    <?= table_search('Search history') ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th data-sort>Date</th>
                <th data-sort>Subject</th>
                <th>Time</th>
                <th>Session</th>
                <th>Your status</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><?= e(date('d M Y', strtotime($row['session_date']))) ?></td>
                <td><strong><?= e($row['subject_code']) ?></strong><br><span class="text-sm muted"><?= e($row['subject_name']) ?></span></td>
                <td><?= e(substr($row['start_time'], 0, 5) . ' - ' . substr($row['end_time'], 0, 5)) ?></td>
                <td><span class="badge badge-<?= e($row['status']) ?>"><?= e($row['status']) ?></span></td>
                <td>
                    <?php if ($row['status'] !== 'FINALIZED'): ?>
                        <span class="badge badge-none">Not counted</span>
                    <?php elseif (!$row['attendance_status']): ?>
                        <span class="badge badge-ABSENT">No mark (counts as not attended)</span>
                    <?php else: ?>
                        <span class="badge badge-<?= e($row['attendance_status']) ?>"><?= e($row['attendance_status']) ?></span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?>
            <tr class="empty-row"><td colspan="5">No attendance sessions found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
