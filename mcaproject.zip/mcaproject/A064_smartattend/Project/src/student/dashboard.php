<?php
require_once __DIR__ . '/../functions.php';
$user      = require_role('Student');
$pdo       = get_pdo();
$studentId = (int) $user['student_id'];

$stmt = $pdo->prepare(
    'SELECT s.roll_no, s.admission_year, s.status, c.semester, c.division, c.academic_year,
            co.course_code, co.course_name, u.name, u.email
     FROM students s
     JOIN users u ON u.user_id = s.user_id
     JOIN classes c ON c.class_id = s.class_id
     JOIN courses co ON co.course_id = c.course_id
     WHERE s.student_id = ?'
);
$stmt->execute([$studentId]);
$profile = $stmt->fetch();

$subStmt = $pdo->prepare(
    'SELECT cs.class_subject_id, sub.subject_code, sub.subject_name, sub.credits, u.name AS teacher_name
     FROM students s
     JOIN class_subjects cs ON cs.class_id = s.class_id
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN teachers t ON t.teacher_id = cs.teacher_id
     JOIN users u ON u.user_id = t.user_id
     WHERE s.student_id = ?
     ORDER BY sub.subject_code'
);
$subStmt->execute([$studentId]);
$subjects = $subStmt->fetchAll();

$statsMap   = attendance_stats_for_student($pdo, $studentId);
$belowCount = 0;
foreach ($subjects as &$sub) {
    $sub['stats'] = $statsMap[(int) $sub['class_subject_id']] ?? attendance_from_counts(0, 0);
    if ($sub['stats']['percent'] !== null && $sub['stats']['percent'] < MIN_ATTENDANCE_PERCENT) {
        $belowCount++;
    }
}
unset($sub);

$pageTitle = 'Student Dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="grid">
    <div class="card">
        <h3>Enrolled subjects</h3>
        <div class="stat"><?= count($subjects) ?></div>
    </div>
    <div class="card">
        <h3>Subjects below 80%</h3>
        <div class="stat <?= $belowCount > 0 ? 'text-bad' : 'text-ok' ?>"><?= $belowCount ?></div>
    </div>
    <?php if ($profile): ?>
    <div class="card">
        <h3>Semester</h3>
        <div class="stat"><?= (int) $profile['semester'] ?></div>
        <div class="stat-note">Division <?= e($profile['division']) ?></div>
    </div>
    <?php endif; ?>
</div>

<?php if ($profile): ?>
<div class="card">
    <h2>My profile</h2>
    <table style="max-width:600px">
        <tbody>
            <tr><td style="width:140px;color:var(--muted);font-size:0.85rem">Name</td><td><strong><?= e($profile['name']) ?></strong></td></tr>
            <tr><td style="color:var(--muted);font-size:0.85rem">Roll number</td><td><code><?= e($profile['roll_no']) ?></code></td></tr>
            <tr><td style="color:var(--muted);font-size:0.85rem">Email</td><td><?= e($profile['email']) ?></td></tr>
            <tr><td style="color:var(--muted);font-size:0.85rem">Course</td><td><?= e($profile['course_code'] . ' &mdash; ' . $profile['course_name']) ?></td></tr>
            <tr><td style="color:var(--muted);font-size:0.85rem">Class</td><td>Semester <?= (int) $profile['semester'] ?>, Division <?= e($profile['division']) ?>, <?= e($profile['academic_year']) ?></td></tr>
            <tr><td style="color:var(--muted);font-size:0.85rem">Admission year</td><td><?= e($profile['admission_year']) ?></td></tr>
            <tr><td style="color:var(--muted);font-size:0.85rem">Account status</td><td><span class="badge badge-<?= e($profile['status']) ?>"><?= e($profile['status']) ?></span></td></tr>
        </tbody>
    </table>
</div>
<?php endif; ?>

<div class="card">
    <h2>Subject-wise attendance</h2>
    <div class="actions">
        <a class="btn" href="<?= e(src_url('student/attendance.php')) ?>">Full session history</a>
        <a class="btn btn-secondary" href="<?= e(src_url('student/report.php')) ?>">Eligibility report</a>
    </div>
    <?php if (!$subjects): ?>
        <p class="muted">No subjects are assigned to your class yet.</p>
    <?php else: ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Subject</th>
                <th>Teacher</th>
                <th>Attended&nbsp;/ Total</th>
                <th>Absences</th>
                <th>Percentage</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($subjects as $sub):
            $st = $sub['stats'];
            $pct = $st['percent'];
        ?>
            <tr>
                <td>
                    <strong><?= e($sub['subject_code']) ?></strong><br>
                    <span class="text-sm muted"><?= e($sub['subject_name']) ?></span>
                </td>
                <td><?= e($sub['teacher_name']) ?></td>
                <td><?= $st['total'] ? ((int) $st['attended'] . ' / ' . (int) $st['total']) : '&mdash;' ?></td>
                <td><?= $st['total'] ? (int) $st['absent'] : '&mdash;' ?></td>
                <td>
                    <?php if ($pct !== null): ?>
                        <strong class="<?= $pct >= 80 ? 'pct-ok' : ($pct >= 60 ? 'pct-warn' : 'pct-bad') ?>">
                            <?= e(format_percent($pct)) ?>
                        </strong>
                        <div style="background:#e2e8f0;border-radius:999px;height:5px;margin-top:4px;width:90px">
                            <div style="height:5px;border-radius:999px;width:<?= min(100, round($pct)) ?>%;background:<?= $pct >= 80 ? 'var(--ok)' : ($pct >= 60 ? 'var(--warn)' : 'var(--danger)') ?>"></div>
                        </div>
                    <?php else: ?>
                        <span class="muted text-sm">No data</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($pct === null): ?>
                        <span class="badge badge-none">No attendance data</span>
                    <?php else: ?>
                        <span class="badge <?= $st['eligible'] ? 'badge-Eligible' : 'badge-Below' ?>">
                            <?= e($st['label']) ?>
                        </span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <p class="muted text-sm" style="margin-top:0.6rem">
        PRESENT and LATE count as attended. ABSENT does not.
        Only FINALIZED sessions are counted. Exactly 80.00% is Eligible.
    </p>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
