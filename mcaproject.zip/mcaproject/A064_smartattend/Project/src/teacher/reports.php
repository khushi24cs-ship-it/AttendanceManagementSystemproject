<?php
require_once __DIR__ . '/../functions.php';
$user = require_role('Teacher');
$pdo = get_pdo();
$teacherId = (int) $user['teacher_id'];
$csId = get_int('class_subject_id');

$asg = $pdo->prepare(
    'SELECT cs.class_subject_id, sub.subject_code, sub.subject_name, c.semester, c.division, co.course_code
     FROM class_subjects cs
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN classes c ON c.class_id = cs.class_id
     JOIN courses co ON co.course_id = c.course_id
     WHERE cs.teacher_id = ?'
);
$asg->execute([$teacherId]);
$assignments = $asg->fetchAll();

$rows = [];
$below = [];
$assignment = null;
if ($csId) {
    $assignment = fetch_teacher_assignment($pdo, $teacherId, $csId);
    if (!$assignment) {
        http_response_code(403);
        exit('You can view reports only for subjects assigned to you.');
    }
    $rows = attendance_stats_map($pdo, $csId);
    foreach ($rows as $student) {
        if ($student['stats']['percent'] !== null && $student['stats']['percent'] < MIN_ATTENDANCE_PERCENT) {
            $below[] = $student;
        }
    }
}

$pageTitle = 'Teacher Reports';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2>Assigned subject report</h2>
    <form method="get">
        <label for="class_subject_id">Class-subject
            <select id="class_subject_id" name="class_subject_id" required>
                <option value="">Select</option>
                <?php foreach ($assignments as $a): ?>
                    <option value="<?= (int) $a['class_subject_id'] ?>" <?= $csId === (int) $a['class_subject_id'] ? 'selected' : '' ?>>
                        <?= e($a['course_code'] . ' / ' . $a['subject_code'] . ' - ' . $a['subject_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <button type="submit" class="btn-outline">View</button>
    </form>
</div>
<?php if ($assignment): ?>
<div class="card">
    <h2>Student-wise attendance &ndash; <?= e($assignment['subject_code'] . ' - ' . $assignment['subject_name']) ?></h2>
    <p class="muted">Class <?= e($assignment['course_code'] . ' Sem ' . $assignment['semester'] . '-' . $assignment['division']) ?>. Exactly 80% is Eligible.</p>
    <?= table_search('Search students') ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th data-sort>Roll</th>
                <th data-sort>Name</th>
                <th data-sort>Attended</th>
                <th data-sort>Absences</th>
                <th data-sort>Total eligible</th>
                <th data-sort>%</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $row): $st = $row['stats']; ?>
            <tr>
                <td><code><?= e($row['roll_no']) ?></code></td>
                <td><?= e($row['name']) ?></td>
                <td><?= $st['total'] ? (int) $st['attended'] : '-' ?></td>
                <td><?= $st['total'] ? (int) $st['absent'] : '-' ?></td>
                <td><?= $st['total'] ? (int) $st['total'] : '-' ?></td>
                <td><?= e(format_percent($st['percent'])) ?></td>
                <td>
                    <?php if ($st['percent'] === null): ?>
                        <span class="badge badge-none">No attendance data</span>
                    <?php else: ?>
                        <span class="badge <?= $st['eligible'] ? 'badge-Eligible' : 'badge-Below' ?>"><?= e($st['label']) ?></span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?>
            <tr class="empty-row"><td colspan="7">No students found for this class.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<div class="card">
    <h2>Students below 80%</h2>
    <?php if (!$below): ?>
        <p>No students are below 80% for this subject<?= $rows && $rows[0]['stats']['percent'] === null ? ', or there is no attendance data yet' : '' ?>.</p>
    <?php else: ?>
        <table>
            <thead><tr><th>Roll</th><th>Name</th><th>Attended / Total</th><th>%</th></tr></thead>
            <tbody>
            <?php foreach ($below as $row): ?>
                <tr>
                    <td><code><?= e($row['roll_no']) ?></code></td>
                    <td><?= e($row['name']) ?></td>
                    <td><?= (int) $row['stats']['attended'] . ' / ' . (int) $row['stats']['total'] ?></td>
                    <td><?= e(format_percent($row['stats']['percent'])) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
