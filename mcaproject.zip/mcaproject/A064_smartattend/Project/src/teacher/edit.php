<?php
require_once __DIR__ . '/../functions.php';
$user = require_role('Teacher');
$pdo = get_pdo();
$teacherId = (int) $user['teacher_id'];
$errors = [];
$sessionId = get_int('session_id') ?: post_int('session_id');

if (!$sessionId) {
    flash_set('error', 'Select a session to edit.');
    redirect('teacher/sessions.php');
}

$stmt = $pdo->prepare(
    'SELECT sess.*, cs.teacher_id, cs.class_id, sub.subject_code, sub.subject_name,
            c.semester, c.division, co.course_code
     FROM attendance_sessions sess
     JOIN class_subjects cs ON cs.class_subject_id = sess.class_subject_id
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN classes c ON c.class_id = cs.class_id
     JOIN courses co ON co.course_id = c.course_id
     WHERE sess.session_id = ?'
);
$stmt->execute([$sessionId]);
$session = $stmt->fetch();

if (!$session || (int) $session['teacher_id'] !== $teacherId) {
    http_response_code(403);
    exit('You can edit attendance only for subjects assigned to you.');
}
if ($session['status'] !== 'FINALIZED') {
    flash_set('error', 'Only finalized sessions can be corrected.');
    redirect('teacher/sessions.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $reason = post_str('reason');
    $statuses = $_POST['status'] ?? [];
    if ($reason === '') {
        $errors[] = 'A reason is required for each attendance correction.';
    }
    if (!$errors && is_array($statuses)) {
        try {
            $pdo->beginTransaction();
            foreach ($statuses as $attendanceId => $status) {
                $check = $pdo->prepare(
                    'SELECT r.attendance_id FROM attendance_records r
                     JOIN attendance_sessions s ON s.session_id = r.session_id
                     JOIN class_subjects cs ON cs.class_subject_id = s.class_subject_id
                     WHERE r.attendance_id = ? AND s.session_id = ? AND cs.teacher_id = ?'
                );
                $check->execute([(int) $attendanceId, $sessionId, $teacherId]);
                if (!$check->fetch()) {
                    throw new RuntimeException('Invalid record.');
                }
                correct_attendance($pdo, (int) $attendanceId, strtoupper(trim((string) $status)), $reason, $user['user_id'], false);
            }
            $pdo->commit();
            flash_set('success', 'Corrections saved. Reports now use the updated marks.');
            redirect('teacher/edit.php?session_id=' . $sessionId);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'The correction could not be saved. Existing records were left unchanged.';
        }
    }
}

$rec = $pdo->prepare(
    'SELECT r.attendance_id, r.attendance_status, st.roll_no, u.name
     FROM attendance_records r
     JOIN students st ON st.student_id = r.student_id
     JOIN users u ON u.user_id = st.user_id
     WHERE r.session_id = ?
     ORDER BY st.roll_no'
);
$rec->execute([$sessionId]);
$records = $rec->fetchAll();

$pageTitle = 'Edit Attendance';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2>Correct a submitted session</h2>
    <div class="session-meta">
        <div><span>Class</span><strong><?= e($session['course_code'] . ' Sem ' . $session['semester'] . '-' . $session['division']) ?></strong></div>
        <div><span>Subject</span><strong><?= e($session['subject_code'] . ' - ' . $session['subject_name']) ?></strong></div>
        <div><span>Date</span><strong><?= e($session['session_date']) ?></strong></div>
        <div><span>Time</span><strong><?= e(substr($session['start_time'], 0, 5) . ' - ' . substr($session['end_time'], 0, 5)) ?></strong></div>
    </div>
    <?php foreach ($errors as $err): ?><div class="alert alert-error" role="alert"><?= e($err) ?></div><?php endforeach; ?>
    <?php if (!$records): ?>
        <p class="muted">No attendance records exist for this session. Incomplete finalized sessions still count in percentage totals.</p>
        <a class="btn btn-secondary" href="<?= e(src_url('teacher/sessions.php')) ?>">Back</a>
    <?php else: ?>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="session_id" value="<?= (int) $sessionId ?>">
        <div class="table-wrap">
        <table>
            <thead><tr><th>Roll</th><th>Name</th><th>Current</th><th>New status</th></tr></thead>
            <tbody>
            <?php foreach ($records as $r): ?>
                <tr>
                    <td><code><?= e($r['roll_no']) ?></code></td>
                    <td><?= e($r['name']) ?></td>
                    <td><span class="badge badge-<?= e($r['attendance_status']) ?>"><?= e($r['attendance_status']) ?></span></td>
                    <td>
                        <select name="status[<?= (int) $r['attendance_id'] ?>]" aria-label="New status for <?= e($r['name']) ?>">
                            <?php foreach (['PRESENT', 'ABSENT', 'LATE'] as $st): ?>
                                <option value="<?= $st ?>" <?= $r['attendance_status'] === $st ? 'selected' : '' ?>><?= $st ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <label for="reason">Reason for correction
            <textarea id="reason" name="reason" required rows="3" maxlength="255"></textarea>
        </label>
        <button type="submit" data-confirm="Save corrections and write audit log entries?">Save corrections</button>
        <a class="btn btn-secondary" href="<?= e(src_url('teacher/sessions.php')) ?>">Back</a>
    </form>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
