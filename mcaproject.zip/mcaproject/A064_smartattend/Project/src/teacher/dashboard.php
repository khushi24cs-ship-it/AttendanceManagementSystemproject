<?php
require_once __DIR__ . '/../functions.php';
$user = require_role('Teacher');
$pdo = get_pdo();
$teacherId = (int) $user['teacher_id'];

$stmt = $pdo->prepare(
    'SELECT cs.class_subject_id, sub.subject_code, sub.subject_name, c.semester, c.division, c.academic_year, co.course_code,
            (SELECT COUNT(*) FROM students s WHERE s.class_id = cs.class_id AND s.status = \'Active\') AS student_count,
            (SELECT COUNT(*) FROM attendance_sessions sess WHERE sess.class_subject_id = cs.class_subject_id AND sess.status = \'FINALIZED\') AS session_count
     FROM class_subjects cs
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN classes c ON c.class_id = cs.class_id
     JOIN courses co ON co.course_id = c.course_id
     WHERE cs.teacher_id = ?
     ORDER BY sub.subject_code'
);
$stmt->execute([$teacherId]);
$assignments = $stmt->fetchAll();

$belowMap = below_counts_for_teacher($pdo, $teacherId);
$belowCount = 0;
foreach ($assignments as &$row) {
    $low = $belowMap[(int) $row['class_subject_id']] ?? 0;
    $row['below_count'] = $low;
    $belowCount += $low;
}
unset($row);

$pageTitle = 'Teacher Dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="grid">
    <div class="card"><h3>Assigned subjects</h3><div class="stat"><?= count($assignments) ?></div></div>
    <div class="card"><h3>Students below 80%</h3><div class="stat <?= $belowCount > 0 ? chr(34)."text-bad".chr(34) : "" ?>"><?= (int) $belowCount ?></div><div class="stat-note">Across assigned subjects</div></div>
</div>
<div class="card">
    <h2>My class-subject assignments</h2>
    <div class="actions">
        <a class="btn" href="<?= e(src_url('teacher/mark.php')) ?>">Mark attendance</a>
        <a class="btn btn-secondary" href="<?= e(src_url('teacher/reports.php')) ?>">Open reports</a>
    </div>
    <?= table_search('Search assignments') ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>Class</th><th>Subject</th><th>Students</th><th>Finalized sessions</th><th>Below 80%</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($assignments as $row): ?>
            <tr>
                <td><?= e($row['course_code'] . ' Sem ' . $row['semester'] . '-' . $row['division'] . ' (' . $row['academic_year'] . ')') ?></td>
                <td><?= e($row['subject_code'] . ' - ' . $row['subject_name']) ?></td>
                <td><?= (int) $row['student_count'] ?></td>
                <td><?= (int) $row['session_count'] ?></td>
                <td><?= (int) $row['below_count'] ?></td>
                <td>
                    <a class="btn btn-small" href="<?= e(src_url('teacher/mark.php?class_subject_id=' . (int) $row['class_subject_id'])) ?>">Mark</a>
                    <a class="btn btn-small btn-outline" href="<?= e(src_url('teacher/reports.php?class_subject_id=' . (int) $row['class_subject_id'])) ?>">Report</a>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$assignments): ?>
            <tr class="empty-row"><td colspan="6">No subjects have been assigned yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
