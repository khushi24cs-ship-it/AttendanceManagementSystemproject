<?php
require_once __DIR__ . '/../functions.php';
$user = require_role('Teacher');
$pdo = get_pdo();
$teacherId = (int) $user['teacher_id'];
$errors = [];

$asgStmt = $pdo->prepare(
    'SELECT cs.class_subject_id, cs.class_id, sub.subject_code, sub.subject_name, c.semester, c.division, co.course_code
     FROM class_subjects cs
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN classes c ON c.class_id = cs.class_id
     JOIN courses co ON co.course_id = c.course_id
     WHERE cs.teacher_id = ?
     ORDER BY sub.subject_code'
);
$asgStmt->execute([$teacherId]);
$assignments = $asgStmt->fetchAll();

$csId = get_int('class_subject_id') ?: post_int('class_subject_id');
$assignment = $csId ? fetch_teacher_assignment($pdo, $teacherId, $csId) : null;
$students = $assignment ? class_students($pdo, (int) $assignment['class_id']) : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && post_str('action') === 'save') {
    require_csrf();
    $csId = post_int('class_subject_id');
    $assignment = fetch_teacher_assignment($pdo, $teacherId, $csId);
    $date = post_str('session_date');
    $start = post_str('start_time');
    $end = post_str('end_time');
    $marks = $_POST['mark'] ?? [];

    if (!$assignment) {
        $errors[] = 'You can mark attendance only for subjects assigned to you.';
    }
    if ($date === '' || $start === '' || $end === '') {
        $errors[] = 'Session date and times are required.';
    } elseif (!is_valid_date($date) || !is_valid_time($start) || !is_valid_time($end)) {
        $errors[] = 'Enter a valid date and time.';
    } elseif ($end <= $start) {
        $errors[] = 'End time must be after start time.';
    }
    if ($assignment) {
        $students = class_students($pdo, (int) $assignment['class_id']);
        $eligible = [];
        foreach ($students as $st) {
            if ($st['status'] === 'Active' && (int) $st['is_active'] === 1) {
                $eligible[(int) $st['student_id']] = $st;
            }
        }
        if (!$eligible) {
            $errors[] = 'There are no active students in this class.';
        }
        foreach ($eligible as $sid => $st) {
            $status = strtoupper(trim((string) ($marks[$sid] ?? '')));
            if (!is_valid_status($status)) {
                $errors[] = 'Mark PRESENT, ABSENT, or LATE for every student.';
                break;
            }
        }
    }

    if (!$errors && $assignment) {
        $pdo->beginTransaction();
        try {
            $ins = $pdo->prepare(
                'INSERT INTO attendance_sessions (class_subject_id, session_date, start_time, end_time, created_by, status)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );
            $ins->execute([$csId, $date, $start, $end, $user['user_id'], 'FINALIZED']);
            $sessionId = (int) $pdo->lastInsertId();
            $rec = $pdo->prepare(
                'INSERT INTO attendance_records (session_id, student_id, attendance_status) VALUES (?, ?, ?)'
            );
            foreach ($eligible as $sid => $st) {
                $rec->execute([$sessionId, $sid, strtoupper($marks[$sid])]);
            }
            $pdo->commit();
            flash_set('success', 'Attendance session saved.');
            redirect('teacher/sessions.php');
        } catch (PDOException $e) {
            $pdo->rollBack();
            if ((int) $e->errorInfo[1] === 1062) {
                $errors[] = 'A duplicate session or student mark was blocked. Each student can have only one mark per session.';
            } else {
                $errors[] = 'Attendance could not be saved. Existing records were not changed.';
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'Attendance could not be saved. Existing records were not changed.';
        }
    }
}


$pageTitle = 'Mark Attendance';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2>Choose assigned class-subject</h2>
    <form method="get">
        <label for="class_subject_id">Assignment
            <select id="class_subject_id" name="class_subject_id" required>
                <option value="">Select a class &amp; subject</option>
                <?php foreach ($assignments as $a): ?>
                    <option value="<?= (int) $a['class_subject_id'] ?>"
                            <?= $csId === (int) $a['class_subject_id'] ? 'selected' : '' ?>>
                        <?= e($a['course_code'] . ' Sem ' . $a['semester'] . '-' . $a['division'] . ' &mdash; ' . $a['subject_code'] . ': ' . $a['subject_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <button type="submit">Load students</button>
        <?php if (!$assignments): ?>
            <p class="muted text-sm" style="margin-top:0.6rem">No subjects are assigned to your account yet. Ask the administrator to create an assignment.</p>
        <?php endif; ?>
    </form>
</div>
<?php if ($assignment): ?>
<div class="card">
    <h2>Mark attendance for this session</h2>
    <div class="session-meta">
        <div><span>Class</span><strong><?= e($assignment['course_code'] . ' Sem ' . $assignment['semester'] . '-' . $assignment['division']) ?></strong></div>
        <div><span>Subject</span><strong><?= e($assignment['subject_code'] . ' &mdash; ' . $assignment['subject_name']) ?></strong></div>
        <div><span>Academic year</span><strong><?= e($assignment['academic_year']) ?></strong></div>
    </div>
    <?php foreach ($errors as $err): ?>
        <div class="alert alert-error" role="alert"><?= e($err) ?></div>
    <?php endforeach; ?>
    <form method="post" data-validate data-attendance>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="class_subject_id" value="<?= (int) $csId ?>">
        <div class="form-row">
            <label for="session_date">Session date
                <input id="session_date" type="date" name="session_date" required
                       value="<?= e($_POST['session_date'] ?? date('Y-m-d')) ?>">
            </label>
            <label for="start_time">Start time
                <input id="start_time" type="time" name="start_time" required
                       value="<?= e($_POST['start_time'] ?? '09:00') ?>">
            </label>
            <label for="end_time">End time
                <input id="end_time" type="time" name="end_time" required
                       value="<?= e($_POST['end_time'] ?? '10:00') ?>">
            </label>
        </div>

        <?php
        // Count eligible students for the bulk bar
        $eligibleCount = 0;
        foreach ($students as $st) {
            if ($st['status'] === 'Active' && (int)$st['is_active'] === 1) $eligibleCount++;
        }
        if ($eligibleCount > 0): ?>
        <div class="bulk-bar">
            <strong>Quick mark all <?= $eligibleCount ?> student<?= $eligibleCount !== 1 ? 's' : '' ?>:</strong>
            <button type="button" data-mark-all="PRESENT"
                    class="btn btn-small" style="background:var(--present);margin:0">&#10003; All PRESENT</button>
            <button type="button" data-mark-all="ABSENT"
                    class="btn btn-small btn-danger" style="margin:0">&#10007; All ABSENT</button>
            <button type="button" data-mark-all="LATE"
                    class="btn btn-small" style="background:var(--late);margin:0">&#9650; All LATE</button>
            <span class="muted text-sm">You can still adjust individual marks below.</span>
        </div>
        <?php endif; ?>

        <?= table_search('Search students') ?>
        <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th style="width:100px">Roll No.</th>
                    <th>Student Name</th>
                    <th>Mark Attendance</th>
                </tr>
            </thead>
            <tbody>
            <?php $shown = 0; foreach ($students as $st):
                if ($st['status'] !== 'Active' || !(int) $st['is_active']) continue;
                $shown++;
            ?>
                <tr data-student="<?= (int) $st['student_id'] ?>">
                    <td><code><?= e($st['roll_no']) ?></code></td>
                    <td><?= e($st['name']) ?></td>
                    <td>
                        <div class="mark-options">
                        <?php foreach (['PRESENT', 'ABSENT', 'LATE'] as $opt): ?>
                            <label>
                                <input type="radio"
                                       name="mark[<?= (int) $st['student_id'] ?>]"
                                       value="<?= $opt ?>"
                                       <?= (($_POST['mark'][$st['student_id']] ?? '') === $opt) ? 'checked' : '' ?>>
                                <?= $opt ?>
                            </label>
                        <?php endforeach; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if ($shown === 0): ?>
                <tr class="empty-row"><td colspan="3">No active students are available to mark.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
        <?php if ($shown): ?>
            <button type="submit" data-confirm="Save attendance for <?= $shown ?> student<?= $shown !== 1 ? 's' : '' ?>? This creates a FINALIZED session.">
                Save attendance &mdash; <?= $shown ?> student<?= $shown !== 1 ? 's' : '' ?>
            </button>
        <?php endif; ?>
    </form>
</div>
<?php elseif ($csId): ?>
<div class="card">
    <div class="alert alert-error">That assignment is not available for your account. Please select one of your assigned subjects.</div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
