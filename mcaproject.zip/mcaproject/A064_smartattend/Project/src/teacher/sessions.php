<?php
require_once __DIR__ . '/../functions.php';
$user = require_role('Teacher');
$pdo = get_pdo();
$teacherId = (int) $user['teacher_id'];
$errors = [];

// ── Load teacher's assigned class-subjects ───────────────────────────────────
$asgStmt = $pdo->prepare(
    'SELECT cs.class_subject_id, sub.subject_code, sub.subject_name,
            c.semester, c.division, co.course_code
     FROM class_subjects cs
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN classes c ON c.class_id = cs.class_id
     JOIN courses co ON co.course_id = c.course_id
     WHERE cs.teacher_id = ?
     ORDER BY sub.subject_code'
);
$asgStmt->execute([$teacherId]);
$assignments = $asgStmt->fetchAll();

// ── Handle POST actions ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = post_str('action');

    // ── Finalize or cancel a session ─────────────────────────────────────────
    if ($action === 'finalize' || $action === 'cancel') {
        $sessionId = post_int('session_id');
        // verify ownership
        $own = $pdo->prepare(
            'SELECT sess.session_id, sess.status FROM attendance_sessions sess
             JOIN class_subjects cs ON cs.class_subject_id = sess.class_subject_id
             WHERE sess.session_id = ? AND cs.teacher_id = ?'
        );
        $own->execute([$sessionId, $teacherId]);
        $sess = $own->fetch();
        if (!$sess) {
            flash_set('error', 'Session not found or you do not own it.');
            redirect('teacher/sessions.php');
        }
        if ($sess['status'] !== 'DRAFT') {
            flash_set('error', 'Only DRAFT sessions can be finalized or cancelled.');
            redirect('teacher/sessions.php');
        }
        $newStatus = $action === 'finalize' ? 'FINALIZED' : 'CANCELLED';
        $pdo->prepare('UPDATE attendance_sessions SET status = ? WHERE session_id = ?')
            ->execute([$newStatus, $sessionId]);
        flash_set('success', 'Session marked as ' . $newStatus . '.');
        redirect('teacher/sessions.php');
    }

    // ── Create a new session ──────────────────────────────────────────────────
    if ($action === 'create') {
        $csId   = post_int('class_subject_id');
        $date   = post_str('session_date');
        $start  = post_str('start_time');
        $end    = post_str('end_time');
        $status = post_str('initial_status');
        if (!in_array($status, ['DRAFT', 'FINALIZED'], true)) {
            $status = 'DRAFT';
        }

        $assignment = fetch_teacher_assignment($pdo, $teacherId, $csId);
        if (!$assignment) {
            $errors[] = 'Select one of your assigned class-subjects.';
        }
        if ($date === '' || $start === '' || $end === '') {
            $errors[] = 'Date, start time, and end time are required.';
        } elseif (!is_valid_date($date) || !is_valid_time($start) || !is_valid_time($end)) {
            $errors[] = 'Enter a valid date and time.';
        } elseif ($end <= $start) {
            $errors[] = 'End time must be after start time.';
        }

        if (!$errors) {
            try {
                $ins = $pdo->prepare(
                    'INSERT INTO attendance_sessions
                        (class_subject_id, session_date, start_time, end_time, created_by, status)
                     VALUES (?, ?, ?, ?, ?, ?)'
                );
                $ins->execute([$csId, $date, $start, $end, $user['user_id'], $status]);
                flash_set('success', 'Session created (' . $status . '). ' .
                    ($status === 'DRAFT' ? 'You can finalize it below when ready.' : 'You can now mark attendance for it.'));
                redirect('teacher/sessions.php');
            } catch (PDOException $e) {
                if ((int) $e->errorInfo[1] === 1062) {
                    $errors[] = 'A session for this subject already exists on that date and start time.';
                } else {
                    $errors[] = 'The session could not be created. Please try again.';
                }
            }
        }
    }
}

// ── Load all sessions for this teacher ──────────────────────────────────────
$sessStmt = $pdo->prepare(
    'SELECT sess.session_id, sess.session_date, sess.start_time, sess.end_time, sess.status,
            sub.subject_code, sub.subject_name, c.semester, c.division
     FROM attendance_sessions sess
     JOIN class_subjects cs ON cs.class_subject_id = sess.class_subject_id
     JOIN subjects sub ON sub.subject_id = cs.subject_id
     JOIN classes c ON c.class_id = cs.class_id
     WHERE cs.teacher_id = ?
     ORDER BY sess.session_date DESC, sess.session_id DESC'
);
$sessStmt->execute([$teacherId]);
$sessions = $sessStmt->fetchAll();

$pageTitle = 'Attendance Sessions';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
    <h2>Create a new session</h2>
    <?php foreach ($errors as $err): ?><div class="alert alert-error" role="alert"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <div class="form-row">
            <label for="csid">Class-subject
                <select id="csid" name="class_subject_id" required>
                    <option value="">Select</option>
                    <?php foreach ($assignments as $a): ?>
                        <option value="<?= (int) $a['class_subject_id'] ?>"
                            <?= (post_int('class_subject_id') === (int) $a['class_subject_id']) ? 'selected' : '' ?>>
                            <?= e($a['course_code'] . ' Sem ' . $a['semester'] . '-' . $a['division'] . ' / ' . $a['subject_code']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label for="session_date">Date
                <input id="session_date" type="date" name="session_date" required
                    value="<?= e(post_str('session_date') ?: date('Y-m-d')) ?>">
            </label>
            <label for="start_time">Start time
                <input id="start_time" type="time" name="start_time" required
                    value="<?= e(post_str('start_time') ?: '09:00') ?>">
            </label>
            <label for="end_time">End time
                <input id="end_time" type="time" name="end_time" required
                    value="<?= e(post_str('end_time') ?: '10:00') ?>">
            </label>
            <label for="initial_status">Save as
                <select id="initial_status" name="initial_status">
                    <option value="DRAFT">DRAFT (mark attendance later)</option>
                    <option value="FINALIZED">FINALIZED (attendance already marked)</option>
                </select>
            </label>
        </div>
        <button type="submit">Create session</button>
    </form>
</div>
<div class="card">
    <h2>Sessions for your assigned subjects</h2>
    <div class="actions">
        <a class="btn" href="<?= e(src_url('teacher/mark.php')) ?>">Mark attendance on a new session</a>
    </div>
    <?= table_search('Search sessions') ?>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th data-sort>Date</th>
                <th data-sort>Subject</th>
                <th data-sort>Class</th>
                <th>Time</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($sessions as $s): ?>
            <tr>
                <td><?= e($s['session_date']) ?></td>
                <td><?= e($s['subject_code'] . ' - ' . $s['subject_name']) ?></td>
                <td><?= e('Sem ' . $s['semester'] . '-' . $s['division']) ?></td>
                <td><?= e(substr($s['start_time'], 0, 5) . ' - ' . substr($s['end_time'], 0, 5)) ?></td>
                <td><span class="badge badge-<?= e($s['status']) ?>"><?= e($s['status']) ?></span></td>
                <td>
                    <?php if ($s['status'] === 'FINALIZED'): ?>
                        <a class="btn btn-small btn-outline" href="<?= e(src_url('teacher/edit.php?session_id=' . (int) $s['session_id'])) ?>">Edit marks</a>
                    <?php elseif ($s['status'] === 'DRAFT'): ?>
                        <a class="btn btn-small" href="<?= e(src_url('teacher/mark.php')) ?>">Mark</a>
                        <form method="post" style="display:inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="finalize">
                            <input type="hidden" name="session_id" value="<?= (int) $s['session_id'] ?>">
                            <button class="btn btn-small" type="submit"
                                data-confirm="Finalize this session? Finalized sessions count in attendance reports.">
                                Finalize
                            </button>
                        </form>
                        <form method="post" style="display:inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="cancel">
                            <input type="hidden" name="session_id" value="<?= (int) $s['session_id'] ?>">
                            <button class="btn btn-small btn-danger" type="submit"
                                data-confirm="Cancel this session? Cancelled sessions are excluded from attendance.">
                                Cancel
                            </button>
                        </form>
                    <?php else: ?>
                        <span class="muted">Cancelled</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$sessions): ?>
            <tr class="empty-row"><td colspan="6">No sessions found for your subjects.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
