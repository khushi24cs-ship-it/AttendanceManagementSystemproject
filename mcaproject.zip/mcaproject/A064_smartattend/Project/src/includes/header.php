<?php
$user  = current_user();
$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? APP_NAME) ?> | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(src_url('css/style.css')) ?>">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>
<?php if ($user): ?>
<button class="sidebar-toggle" aria-label="Toggle navigation" aria-expanded="false">&#9776;</button>
<div class="sidebar-overlay"></div>
<div class="layout">
    <aside class="sidebar">
        <div class="brand">
            <strong>Smart Attend</strong>
            <span><?= e($user['role']) ?> workspace</span>
        </div>
        <nav aria-label="Main">
            <?php if ($user['role'] === 'Admin'): ?>
                <a href="<?= e(src_url('admin/dashboard.php')) ?>"<?= nav_active('admin/dashboard.php') ?>>Dashboard</a>
                <a href="<?= e(src_url('admin/students.php')) ?>"<?= nav_active('admin/students.php') ?>>Students</a>
                <a href="<?= e(src_url('admin/teachers.php')) ?>"<?= nav_active('admin/teachers.php') ?>>Teachers</a>
                <a href="<?= e(src_url('admin/courses.php')) ?>"<?= nav_active('admin/courses.php') ?>>Courses</a>
                <a href="<?= e(src_url('admin/classes.php')) ?>"<?= nav_active('admin/classes.php') ?>>Classes</a>
                <a href="<?= e(src_url('admin/subjects.php')) ?>"<?= nav_active('admin/subjects.php') ?>>Subjects</a>
                <a href="<?= e(src_url('admin/assignments.php')) ?>"<?= nav_active('admin/assignments.php') ?>>Assignments</a>
                <a href="<?= e(src_url('admin/reports.php')) ?>"<?= nav_active('admin/reports.php') ?>>Reports</a>
                <a href="<?= e(src_url('admin/audit.php')) ?>"<?= nav_active('admin/audit.php') ?>>Audit logs</a>
                <a href="<?= e(src_url('admin/correct.php')) ?>"<?= nav_active('admin/correct.php') ?>>Correct attendance</a>
            <?php elseif ($user['role'] === 'Teacher'): ?>
                <a href="<?= e(src_url('teacher/dashboard.php')) ?>"<?= nav_active('teacher/dashboard.php') ?>>Dashboard</a>
                <a href="<?= e(src_url('teacher/sessions.php')) ?>"<?= nav_active('teacher/sessions.php') ?>>Sessions</a>
                <a href="<?= e(src_url('teacher/mark.php')) ?>"<?= nav_active('teacher/mark.php') ?>>Mark attendance</a>
                <a href="<?= e(src_url('teacher/reports.php')) ?>"<?= nav_active('teacher/reports.php') ?>>Reports</a>
            <?php else: ?>
                <a href="<?= e(src_url('student/dashboard.php')) ?>"<?= nav_active('student/dashboard.php') ?>>Dashboard</a>
                <a href="<?= e(src_url('student/attendance.php')) ?>"<?= nav_active('student/attendance.php') ?>>My attendance</a>
                <a href="<?= e(src_url('student/report.php')) ?>"<?= nav_active('student/report.php') ?>>Report</a>
            <?php endif; ?>
            <div class="nav-foot">
                <a href="<?= e(src_url('logout.php')) ?>">&#8594; Logout</a>
            </div>
        </nav>
    </aside>
    <div class="main">
        <header class="topbar">
            <h1><?= e($pageTitle ?? APP_NAME) ?></h1>
            <p>Signed in as <strong><?= e($user['name']) ?></strong> &middot; <?= e($user['role']) ?></p>
        </header>
        <main class="content" id="main">
            <?php if ($flash): ?>
                <div class="alert alert-<?= e($flash['type'] === 'error' ? 'error' : 'success') ?>" role="status">
                    <?= e($flash['message']) ?>
                </div>
            <?php endif; ?>
<?php else: ?>
<main class="auth-wrap" id="main">
    <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type'] === 'error' ? 'error' : 'success') ?>" role="status">
            <?= e($flash['message']) ?>
        </div>
    <?php endif; ?>
<?php endif; ?>
