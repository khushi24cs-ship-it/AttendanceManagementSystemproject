<?php if (current_user()): ?>
        </main>
    </div>
</div>
<?php else: ?>
</main>
<?php endif; ?>
<script src="<?= e(src_url('js/app.js')) ?>"></script>
</body>
</html>
