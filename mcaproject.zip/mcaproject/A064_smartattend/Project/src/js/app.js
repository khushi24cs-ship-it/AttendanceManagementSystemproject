(function () {
    'use strict';

    /* ── Utilities ────────────────────────────────────────────────────────── */
    function showError(form, message) {
        var existing = form.querySelector('.js-error');
        if (!existing) {
            existing = document.createElement('div');
            existing.className = 'alert alert-error js-error';
            existing.setAttribute('role', 'alert');
            form.insertBefore(existing, form.firstChild);
        }
        existing.textContent = message;
        existing.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function markSubmitting(form) {
        var btn = form.querySelector('button[type="submit"], button:not([type])');
        if (btn && !btn.disabled) {
            btn.classList.add('is-loading');
            btn.disabled = true;
            btn.setAttribute('data-label', btn.textContent);
            btn.textContent = 'Please wait\u2026';
        }
    }

    /* ── Standard form validation ─────────────────────────────────────────── */
    document.querySelectorAll('form[data-validate]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            var required = form.querySelectorAll('[required]');
            for (var i = 0; i < required.length; i++) {
                if (!String(required[i].value || '').trim()) {
                    event.preventDefault();
                    showError(form, 'Please fill in all required fields.');
                    required[i].focus();
                    return;
                }
            }
            var emailInput = form.querySelector('input[type="email"]');
            if (emailInput && emailInput.value) {
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.value)) {
                    event.preventDefault();
                    showError(form, 'Please enter a valid email address.');
                    emailInput.focus();
                    return;
                }
            }
            if (!form.hasAttribute('data-attendance')) {
                markSubmitting(form);
            }
        });
    });

    /* ── Attendance form validation ───────────────────────────────────────── */
    document.querySelectorAll('form[data-attendance]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            var groups = form.querySelectorAll('[data-student]');
            for (var i = 0; i < groups.length; i++) {
                var radios = groups[i].querySelectorAll('input[type="radio"]');
                var checked = false;
                for (var j = 0; j < radios.length; j++) {
                    if (radios[j].checked) { checked = true; break; }
                }
                if (!checked) {
                    event.preventDefault();
                    showError(form, 'Mark PRESENT, ABSENT, or LATE for every student before submitting.');
                    groups[i].scrollIntoView({ behavior: 'smooth', block: 'center' });
                    return;
                }
            }
            markSubmitting(form);
        });
    });

    /* ── Bulk "Mark all PRESENT" button ───────────────────────────────────── */
    var markAllBtn = document.getElementById('btn-mark-all-present');
    if (markAllBtn) {
        markAllBtn.addEventListener('click', function () {
            var form = markAllBtn.closest('form');
            if (!form) return;
            form.querySelectorAll('[data-student]').forEach(function (row) {
                var radio = row.querySelector('input[type="radio"][value="PRESENT"]');
                if (radio) radio.checked = true;
            });
        });
    }

    /* ── Quick mark buttons (PRESENT/ABSENT/LATE all) ─────────────────────── */
    document.querySelectorAll('[data-mark-all]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var status = btn.getAttribute('data-mark-all');
            var form = btn.closest('form');
            if (!form) return;
            form.querySelectorAll('[data-student]').forEach(function (row) {
                var radio = row.querySelector('input[type="radio"][value="' + status + '"]');
                if (radio) radio.checked = true;
            });
        });
    });

    /* ── Confirm dialogs ──────────────────────────────────────────────────── */
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('click', function (event) {
            var message = el.getAttribute('data-confirm') || 'Are you sure?';
            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });
    });

    /* ── Table live search ────────────────────────────────────────────────── */
    document.querySelectorAll('[data-table-search]').forEach(function (input) {
        var card  = input.closest('.card') || document;
        var table = card.querySelector('table');
        var count = card.querySelector('.table-count');
        if (!table) return;

        input.addEventListener('input', function () {
            var q = input.value.toLowerCase().trim();
            var visible = 0;
            table.querySelectorAll('tbody tr').forEach(function (row) {
                if (row.classList.contains('empty-row')) return;
                var show = q === '' || row.textContent.toLowerCase().includes(q);
                row.hidden = !show;
                if (show) visible++;
            });
            if (count) {
                var total = table.querySelectorAll('tbody tr:not(.empty-row)').length;
                count.textContent = q ? (visible + ' of ' + total + ' shown') : (total + ' record' + (total !== 1 ? 's' : ''));
            }
        });

        // Show initial count
        if (count) {
            var total = table.querySelectorAll('tbody tr:not(.empty-row)').length;
            count.textContent = total + ' record' + (total !== 1 ? 's' : '');
        }
    });

    /* ── Table column sort ────────────────────────────────────────────────── */
    document.querySelectorAll('th[data-sort]').forEach(function (th) {
        th.setAttribute('tabindex', '0');
        th.setAttribute('role', 'button');
        function sortBy() {
            var table = th.closest('table');
            var tbody = table.querySelector('tbody');
            if (!tbody) return;
            var index = Array.prototype.indexOf.call(th.parentNode.children, th);
            var rows  = Array.prototype.slice.call(tbody.querySelectorAll('tr')).filter(function (r) {
                return !r.classList.contains('empty-row') && !r.hidden;
            });
            var dir = th.getAttribute('data-dir') === 'asc' ? 'desc' : 'asc';
            th.parentNode.querySelectorAll('th').forEach(function (o) { o.removeAttribute('data-dir'); });
            th.setAttribute('data-dir', dir);
            rows.sort(function (a, b) {
                var av = (a.children[index] ? a.children[index].textContent : '').trim().toLowerCase();
                var bv = (b.children[index] ? b.children[index].textContent : '').trim().toLowerCase();
                var an = parseFloat(av), bn = parseFloat(bv);
                var cmp = (!isNaN(an) && !isNaN(bn)) ? (an - bn) : av.localeCompare(bv);
                return dir === 'asc' ? cmp : -cmp;
            });
            rows.forEach(function (row) { tbody.appendChild(row); });
        }
        th.addEventListener('click', sortBy);
        th.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); sortBy(); }
        });
    });

    /* ── Auto-dismiss success flash alerts ────────────────────────────────── */
    document.querySelectorAll('.content > .alert-success, .auth-wrap > .alert-success').forEach(function (el) {
        setTimeout(function () {
            el.classList.add('fade-out');
            setTimeout(function () { el.style.display = 'none'; }, 450);
        }, 5000);
    });

    /* ── Textarea character counter ───────────────────────────────────────── */
    document.querySelectorAll('textarea[maxlength]').forEach(function (ta) {
        var max     = parseInt(ta.getAttribute('maxlength'), 10);
        var counter = document.createElement('span');
        counter.className = 'char-counter';
        ta.insertAdjacentElement('afterend', counter);
        function update() {
            var rem = max - ta.value.length;
            counter.textContent = rem + ' characters remaining';
            counter.classList.toggle('near-limit', rem < 40 && rem >= 10);
            counter.classList.toggle('at-limit',   rem < 10);
        }
        ta.addEventListener('input', update);
        update();
    });

    /* ── Colour-code percentage cells ─────────────────────────────────────── */
    document.querySelectorAll('td').forEach(function (td) {
        var txt = td.textContent.trim();
        if (!/^\d+\.\d+%$/.test(txt)) return;
        var pct = parseFloat(txt);
        if (isNaN(pct)) return;
        if (pct >= 80)       td.classList.add('pct-ok');
        else if (pct >= 60)  td.classList.add('pct-warn');
        else                 td.classList.add('pct-bad');
    });

    /* ── Login page quick-fill buttons ───────────────────────────────────── */
    document.querySelectorAll('[data-fill-email][data-fill-pass]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var emailEl = document.getElementById('email');
            var passEl  = document.getElementById('password');
            if (emailEl) emailEl.value = btn.getAttribute('data-fill-email');
            if (passEl)  passEl.value  = btn.getAttribute('data-fill-pass');
        });
    });

    /* ── Mobile sidebar toggle ────────────────────────────────────────────── */
    var toggleBtn = document.querySelector('.sidebar-toggle');
    var sidebar   = document.querySelector('.sidebar');
    var overlay   = document.querySelector('.sidebar-overlay');
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function () {
            var open = sidebar.classList.toggle('is-open');
            if (overlay) overlay.classList.toggle('is-visible', open);
            toggleBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        if (overlay) {
            overlay.addEventListener('click', function () {
                sidebar.classList.remove('is-open');
                overlay.classList.remove('is-visible');
                toggleBtn.setAttribute('aria-expanded', 'false');
            });
        }
    }

})();
