
class Stack<T> {
    T[] arr;
    int top = -1;
    int size;

    @SuppressWarnings("unchecked")
    Stack(int size) {
        this.size = size;
        arr = (T[]) new Object[size];
    }

    void push(T item) {
        if (top == size - 1) {
            System.out.println("Stack is full");
            return;
        }

        arr[++top] = item;
        System.out.println(item + " pushed");
    }

    T pop() {
        if (top == -1) {
            throw new RuntimeException("Stack is empty");
        }

        return arr[top--];
    }

    T peek() {
        if (top == -1) {
            throw new RuntimeException("Stack is empty");
        }

        return arr[top];
    }
}

public class GenericStackDemo {
    public static void main(String[] args) {
        Stack<Integer> s = new Stack<Integer>(5);

        s.push(10);
        s.push(20);
        s.push(30);

        System.out.println("Top element: " + s.peek());
        System.out.println("Popped: " + s.pop());
        System.out.println("Top element: " + s.peek());
    }
}
