
import java.util.Scanner;

public class GenericMethodDemo {

    static <T, U> void operation(T a, U b, int choice) {

        if (a instanceof Number && b instanceof Number) {
            double x = ((Number) a).doubleValue();
            double y = ((Number) b).doubleValue();

            if (choice == 1) {
                System.out.println("Addition = " + (x + y));
            } else if (choice == 2) {
                System.out.println("Subtraction = " + (x - y));
            } else {
                System.out.println("Invalid choice");
            }

        } else if (a instanceof String && b instanceof String) {
            String s1 = (String) a;
            String s2 = (String) b;

            if (choice == 1) {
                System.out.println("Concatenation = " + s1 + s2);
            } else if (choice == 2) {
                if (s2.length() <= s1.length()) {
                    System.out.println("Substring = "
                            + s1.substring(0, s2.length()));
                } else {
                    System.out.println("Second string is too long.");
                }
            } else {
                System.out.println("Invalid choice");
            }

        } else {
            System.out.println("Both objects must be numbers or both strings.");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter first number: ");
        Integer a = sc.nextInt();

        System.out.print("Enter second number: ");
        Integer b = sc.nextInt();

        System.out.print("Enter choice (1-Addition, 2-Subtraction): ");
        int choice = sc.nextInt();

        operation(a, b, choice);

        sc.close();
    }
}
