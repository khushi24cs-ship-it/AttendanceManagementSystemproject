
class Test<T, U> {
    T obj1;
    U obj2;

    Test(T obj1, U obj2) {
        this.obj1 = obj1;
        this.obj2 = obj2;
    }

    public void print() {
        System.out.println("String object: " + obj1);
        System.out.println("Integer object: " + obj2);
    }
}

public class GenericClassDemo {
    public static void main(String[] args) {
        Test<String, Integer> obj =
                new Test<String, Integer>("Class of BTech Integrated", 15);

        obj.print();
    }
}
