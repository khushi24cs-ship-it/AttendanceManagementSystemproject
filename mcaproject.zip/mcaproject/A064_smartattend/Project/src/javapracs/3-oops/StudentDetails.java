
import java.util.Scanner;

class Student {
    private String name;
    private int rollno;
    private int total_marks;

    void assign(String name, int rollno, int total_marks) {
        this.name = name;
        this.rollno = rollno;
        this.total_marks = total_marks;
    }

    void display() {
        System.out.println("\nStudent Details");
        System.out.println("Name         : " + name);
        System.out.println("Roll Number  : " + rollno);
        System.out.println("Total Marks  : " + total_marks);
    }
}

public class StudentDetails{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the name of the student: ");
        String name = sc.nextLine();

        System.out.print("Enter the Roll Number of the student: ");
        int rollno = sc.nextInt();

        System.out.print("Enter the Total Marks of the student: ");
        int total_marks = sc.nextInt();

        Student s = new Student();
        s.assign(name, rollno, total_marks);
        s.display();

        sc.close();
    }
}
