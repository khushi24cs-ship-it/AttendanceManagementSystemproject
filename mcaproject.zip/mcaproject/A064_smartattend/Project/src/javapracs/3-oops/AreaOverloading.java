
class Area {

    void area(int side) {
        System.out.println("Area of Square = " + (side * side));
    }

    void area(int length, int breadth) {
        System.out.println("Area of Rectangle = " + (length * breadth));
    }

    void area(double radius) {
        System.out.println("Area of Circle = " + (3.14 * radius * radius));
    }

    void area(double base, double height, int triangle) {
        System.out.println("Area of Triangle = " + (0.5 * base * height));
    }
}

public class AreaOverloading {
    public static void main(String[] args) {
        Area a = new Area();

        a.area(5);
        a.area(10, 4);
        a.area(7.0);
        a.area(8.0, 6.0, 1);
    }
}
