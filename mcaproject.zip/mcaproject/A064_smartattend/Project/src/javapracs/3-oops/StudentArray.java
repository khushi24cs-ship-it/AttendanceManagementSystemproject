
import java.util.Scanner;

class Student {
    private String name;
    private int rollno;
    private int total_marks;

    void assign(String name, int rollno, int total_marks) {
        this.name = name;
        this.rollno = rollno;
        this.total_marks = total_marks;
    }

    void display() {
        System.out.println("\nStudent Details");
        System.out.println("Name         : " + name);
        System.out.println("Roll Number  : " + rollno);
        System.out.println("Total Marks  : " + total_marks);
    }
}

public class StudentArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();
        sc.nextLine();

        Student[] students = new Student[n];

        for (int i = 0; i < n; i++) {
            students[i] = new Student();

            System.out.println("\nEnter details of Student " + (i + 1));

            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Roll Number: ");
            int rollno = sc.nextInt();

            System.out.print("Enter Total Marks: ");
            int total_marks = sc.nextInt();
            sc.nextLine();

            students[i].assign(name, rollno, total_marks);
        }

        System.out.println("\n--- All Student Details ---");

        for (int i = 0; i < n; i++) {
            students[i].display();
        }

        sc.close();
    }
}
