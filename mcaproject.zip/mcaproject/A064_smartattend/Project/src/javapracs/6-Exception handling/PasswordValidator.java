
import java.util.Scanner;

class WeakPasswordException extends Exception {
    public WeakPasswordException(String message) {
        super(message);
    }
}

public class PasswordValidator {

    static void validatePassword(String password)
            throws WeakPasswordException {

        if (password.length() < 8) {
            throw new WeakPasswordException(
                "Password must contain at least 8 characters.");
        }

        boolean hasDigit = false;
        boolean hasSpecialCharacter = false;

        for (char ch : password.toCharArray()) {
            if (Character.isDigit(ch)) {
                hasDigit = true;
            }

            if (!Character.isLetterOrDigit(ch)) {
                hasSpecialCharacter = true;
            }
        }

        if (!hasDigit) {
            throw new WeakPasswordException(
                "Password must contain at least one digit.");
        }

        if (!hasSpecialCharacter) {
            throw new WeakPasswordException(
                "Password must contain at least one special character.");
        }

        System.out.println("Password is strong.");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter password: ");
            String password = sc.nextLine();

            validatePassword(password);

        } catch (WeakPasswordException e) {
            System.out.println("WeakPasswordException: "
                + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
