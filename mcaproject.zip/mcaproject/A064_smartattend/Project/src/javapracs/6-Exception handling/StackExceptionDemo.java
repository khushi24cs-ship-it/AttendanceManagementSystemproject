
import java.util.InputMismatchException;
import java.util.Scanner;

class Stack {
    private int[] stack;
    private int top;
    private int size;

    Stack(int size) {
        this.size = size;
        stack = new int[size];
        top = -1;
    }

    void push(int value) {
        if (top == size - 1) {
            throw new RuntimeException("Stack Overflow: Stack is full.");
        }

        stack[++top] = value;
        System.out.println(value + " pushed into stack.");
    }

    int pop() {
        if (top == -1) {
            throw new RuntimeException("Stack Underflow: Stack is empty.");
        }

        return stack[top--];
    }

    void display() {
        if (top == -1) {
            System.out.println("Stack is empty.");
            return;
        }

        System.out.println("Stack elements are:");
        for (int i = top; i >= 0; i--) {
            System.out.println(stack[i]);
        }
    }
}

public class StackExceptionDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter stack size: ");
            int size = sc.nextInt();

            if (size <= 0) {
                System.out.println("Stack size must be positive.");
                return;
            }

            Stack s = new Stack(size);

            while (true) {
                System.out.println("\n1. Push");
                System.out.println("2. Pop");
                System.out.println("3. Display");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");

                int choice = sc.nextInt();

                try {
                    switch (choice) {
                        case 1:
                            System.out.print("Enter integer to push: ");
                            int value = sc.nextInt();
                            s.push(value);
                            break;

                        case 2:
                            System.out.println("Popped element: " + s.pop());
                            break;

                        case 3:
                            s.display();
                            break;

                        case 4:
                            System.out.println("Exiting program.");
                            return;

                        default:
                            System.out.println("Invalid choice.");
                    }
                } catch (RuntimeException e) {
                    System.out.println(e.getMessage());
                }
            }

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter integers only.");
        } finally {
            sc.close();
        }
    }
}
