
import java.util.InputMismatchException;
import java.util.Scanner;

class CourseFullException extends Exception {
    public CourseFullException(String message) {
        super(message);
    }
}

class IneligibleStudentException extends Exception {
    public IneligibleStudentException(String message) {
        super(message);
    }
}

public class StudentEnrollment {
    static int capacity = 2;
    static int enrolled = 0;

    static void enrollStudent(int age)
            throws CourseFullException, IneligibleStudentException {

        if (age < 20) {
            throw new IneligibleStudentException(
                "Student is not eligible. Age must be 20 or above.");
        }

        if (enrolled >= capacity) {
            throw new CourseFullException(
                "Course is full. No more students can be enrolled.");
        }

        enrolled++;

        System.out.println("Student enrolled successfully.");
        System.out.println("Total enrolled students: " + enrolled);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter student age: ");
            int age = sc.nextInt();

            try {
                enrollStudent(age);
            } catch (IneligibleStudentException |
                     CourseFullException e) {
                System.out.println("Exception: " + e.getMessage());
            }

        } catch (InputMismatchException e) {
            System.out.println("Please enter a valid integer age.");
        } finally {
            sc.close();
        }
    }
}
