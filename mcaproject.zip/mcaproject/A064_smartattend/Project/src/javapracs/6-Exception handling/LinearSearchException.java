
import java.util.InputMismatchException;
import java.util.Scanner;

public class LinearSearchException {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter number of elements: ");
            int n = sc.nextInt();

            if (n <= 0) {
                System.out.println("Number of elements must be positive.");
                return;
            }

            int[] arr = new int[n];

            System.out.println("Enter " + n + " integer elements:");
            for (int i = 0; i < n; i++) {
                arr[i] = sc.nextInt();
            }

            System.out.print("Enter element to search: ");
            int key = sc.nextInt();

            boolean found = false;

            for (int i = 0; i < n; i++) {
                if (arr[i] == key) {
                    System.out.println("Element found at index: " + i);
                    found = true;
                    break;
                }
            }

            if (!found) {
                System.out.println("Element not found.");
            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Exception: Array index is out of bounds.");
        } catch (InputMismatchException e) {
            System.out.println("Exception: Please enter integers only.");
        } finally {
            sc.close();
            System.out.println("Program execution completed.");
        }
    }
}
