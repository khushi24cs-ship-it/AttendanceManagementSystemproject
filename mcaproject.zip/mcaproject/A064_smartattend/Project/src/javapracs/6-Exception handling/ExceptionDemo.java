
public class ExceptionDemo {
    public static void main(String[] args) {

        // ArrayIndexOutOfBoundsException
        try {
            int[] arr = {10, 20, 30};

            System.out.println("Element at index 1: " + arr[1]);
            System.out.println("Element at index 5: " + arr[5]);

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException caught.");
            System.out.println("Invalid array index.");
        }

        // NumberFormatException
        try {
            String str = "ABC123";
            int number = Integer.parseInt(str);

            System.out.println("Number: " + number);

        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException caught.");
            System.out.println("String cannot be converted into an integer.");
        }

        System.out.println("Program completed successfully.");
    }
}
