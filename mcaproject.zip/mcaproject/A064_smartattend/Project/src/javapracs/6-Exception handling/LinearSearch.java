
import java.util.Scanner;

public class LinearSearch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            int a[] = new int[5];

            System.out.println("Enter 5 elements:");
            for (int i = 0; i < 5; i++)
                a[i] = sc.nextInt();

            System.out.print("Enter element to search: ");
            int key = sc.nextInt();

            int i;
            for (i = 0; i < 5; i++) {
                if (a[i] == key) {
                    System.out.println("Element found at position " + (i + 1));
                    break;
                }
            }

            if (i == 5)
                System.out.println("Element not found");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index out of bounds");
        }
        catch (java.util.InputMismatchException e) {
            System.out.println("Please enter integers only");
        }

        sc.close();
    }
}
