import java.util.Scanner;
import person.Teacher;
import company.Manager;

public class PackageDemo {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Teacher Code: ");
        int tCode = sc.nextInt();
        sc.nextLine();

        System.out.print("Teacher Name: ");
        String tName = sc.nextLine();

        System.out.print("Lectures Conducted: ");
        int lectures = sc.nextInt();

        System.out.print("Salary Per Lecture: ");
        double spl = sc.nextDouble();

        Teacher t = new Teacher(
                tCode, tName, lectures, spl);

        System.out.print("\nManager Code: ");
        int mCode = sc.nextInt();
        sc.nextLine();

        System.out.print("Manager Name: ");
        String mName = sc.nextLine();

        System.out.print("Salary: ");
        double salary = sc.nextDouble();

        System.out.print("Unit Of Sales: ");
        int sales = sc.nextInt();

        Manager m = new Manager(
                mCode, mName, salary, sales);

        t.display();
        m.display();

        sc.close();
    }
}
