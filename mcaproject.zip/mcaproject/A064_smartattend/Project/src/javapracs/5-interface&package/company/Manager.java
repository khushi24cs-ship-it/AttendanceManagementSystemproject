package company;

import person.Employee;

public class Manager extends Employee {

    double salary;
    int unitOfSales;

    public Manager(int code, String name,
                   double salary,
                   int unitOfSales) {

        super(code, name);
        this.salary = salary;
        this.unitOfSales = unitOfSales;
    }

    public double calculate() {

        if (unitOfSales < 100)
            return salary * 0.10;
        else if (unitOfSales < 200)
            return salary * 0.15;
        else
            return salary * 0.20;
    }

    @Override
    public void display() {
        System.out.println("\nManager Details");
        super.display();
        System.out.println("Salary : " + salary);
        System.out.println("Unit Of Sales : " + unitOfSales);
        System.out.println("Bonus : " + calculate());
    }
}
