package person;

public class Employee {
    protected int code;
    protected String name;

    public Employee(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public void display() {
        System.out.println("Code : " + code);
        System.out.println("Name : " + name);
    }
}
