package person;

public class Teacher extends Employee {

    int lecturesConducted;
    double salaryPerLecture;

    public Teacher(int code, String name,
                   int lecturesConducted,
                   double salaryPerLecture) {

        super(code, name);
        this.lecturesConducted = lecturesConducted;
        this.salaryPerLecture = salaryPerLecture;
    }

    public double calculate() {
        return lecturesConducted * salaryPerLecture;
    }

    @Override
    public void display() {
        System.out.println("\nTeacher Details");
        super.display();
        System.out.println("Lectures Conducted : " + lecturesConducted);
        System.out.println("Salary Per Lecture : " + salaryPerLecture);
        System.out.println("Total Salary : " + calculate());
    }
}
