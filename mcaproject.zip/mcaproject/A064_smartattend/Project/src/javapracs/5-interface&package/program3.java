
import java.util.Scanner;

interface Sport {
    int sport_point = 10;

    void calculate();
}

class Student {
    int rollNo;
    String name;

    Student(int rollNo, String name) {
        this.rollNo = rollNo;
        this.name = name;
    }
}

class Test extends Student {
    int mark1, mark2;

    Test(int rollNo, String name, int mark1, int mark2) {
        super(rollNo, name);
        this.mark1 = mark1;
        this.mark2 = mark2;
    }
}

class Result extends Test implements Sport {

    Result(int rollNo, String name, int mark1, int mark2) {
        super(rollNo, name, mark1, mark2);
    }

    @Override
    public void calculate() {
        int totalMarks = mark1 + mark2 + sport_point;

        System.out.println("\n------ Result Details ------");
        System.out.println("Roll No : " + rollNo);
        System.out.println("Name : " + name);
        System.out.println("Mark 1 : " + mark1);
        System.out.println("Mark 2 : " + mark2);
        System.out.println("Sport Points : " + sport_point);
        System.out.println("Total Marks : " + totalMarks);
    }
}

public class program3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Roll Number: ");
        int rollNo = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Mark 1: ");
        int mark1 = sc.nextInt();

        System.out.print("Enter Mark 2: ");
        int mark2 = sc.nextInt();

        Result r = new Result(rollNo, name, mark1, mark2);
        r.calculate();

        sc.close();
    }
}
