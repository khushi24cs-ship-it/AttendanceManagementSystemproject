
import java.util.*;

public class ScoreDemo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TreeSet<Integer> scores = new TreeSet<>();

        while (true) {
            System.out.println("\n1. ADD_SCORE");
            System.out.println("2. REMOVE_SCORE");
            System.out.println("3. HIGHEST_SCORE");
            System.out.println("4. LOWEST_SCORE");
            System.out.println("5. COUNT_RANGE");
            System.out.println("6. NEXT_SCORE");
            System.out.println("7. PREV_SCORE");
            System.out.println("8. PRINT_SCORES");
            System.out.println("9. EXIT");

            System.out.print("Enter choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    System.out.print("Enter score: ");
                    int score = sc.nextInt();

                    if (score < 0 || score > 100) {
                        System.out.println("Invalid score");
                    } else {
                        scores.add(score);
                        System.out.println("Score added");
                    }
                    break;

                case 2:
                    System.out.print("Enter score to remove: ");
                    score = sc.nextInt();

                    if (scores.remove(score)) {
                        System.out.println("Score removed");
                    } else {
                        System.out.println("Score not found");
                    }
                    break;

                case 3:
                    if (scores.isEmpty()) {
                        System.out.println("NO SCORES");
                    } else {
                        System.out.println("Highest: " + scores.last());
                    }
                    break;

                case 4:
                    if (scores.isEmpty()) {
                        System.out.println("NO SCORES");
                    } else {
                        System.out.println("Lowest: " + scores.first());
                    }
                    break;

                case 5:
                    System.out.print("Enter lower bound: ");
                    int low = sc.nextInt();

                    System.out.print("Enter upper bound: ");
                    int high = sc.nextInt();

                    if (low > high) {
                        System.out.println("Invalid range");
                    } else {
                        System.out.println("Count: " +
                            scores.subSet(low, true, high, true).size());
                    }
                    break;

                case 6:
                    System.out.print("Enter s: ");
                    int s = sc.nextInt();

                    Integer next = scores.ceiling(s);

                    if (next == null) {
                        System.out.println("NO NEXT SCORE");
                    } else {
                        System.out.println("Next Score: " + next);
                    }
                    break;

                case 7:
                    System.out.print("Enter s: ");
                    s = sc.nextInt();

                    Integer prev = scores.floor(s);

                    if (prev == null) {
                        System.out.println("NO PREV SCORE");
                    } else {
                        System.out.println("Previous Score: " + prev);
                    }
                    break;

                case 8:
                    if (scores.isEmpty()) {
                        System.out.println("NO SCORES");
                    } else {
                        System.out.println(
                            "Scores: " + scores.descendingSet());
                    }
                    break;

                case 9:
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
