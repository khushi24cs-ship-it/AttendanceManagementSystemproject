
import java.util.*;

public class SetDemo {

    static Set<Integer> createSet(int a[]) {
        Set<Integer> s = new HashSet<>();

        for (int x : a) {
            s.add(x);
        }

        return s;
    }

    static Set<Integer> operation(Set<Integer> a,
                                  Set<Integer> b, int ch) {
        Set<Integer> s = new HashSet<>(a);

        switch (ch) {
            case 1:
                s.addAll(b);
                break;

            case 2:
                s.retainAll(b);
                break;

            case 3:
                s.removeAll(b);
                break;

            default:
                System.out.println("Invalid choice");
        }

        return s;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Set<Integer> s1 = new HashSet<>();

        s1.add(10);
        s1.add(20);
        s1.add(30);
        s1.add(40);

        System.out.println("Set: " + s1);

        System.out.println("Elements using Iterator:");
        Iterator<Integer> it = s1.iterator();

        while (it.hasNext()) {
            System.out.println(it.next());
        }

        System.out.print("Enter element to search: ");
        int n = sc.nextInt();

        if (s1.contains(n)) {
            System.out.println("Element exists");
        } else {
            System.out.println("Element does not exist");
        }

        System.out.print("Enter element to remove: ");
        n = sc.nextInt();

        if (s1.remove(n)) {
            System.out.println("Element removed");
        } else {
            System.out.println("Element not found");
        }

        System.out.println("Updated Set: " + s1);

        int a[] = {10, 20, 20, 30, 40, 40};

        Set<Integer> s2 = createSet(a);
        System.out.println("Set without duplicates: " + s2);

        Set<Integer> b = new HashSet<>();
        b.add(30);
        b.add(40);
        b.add(50);
        b.add(60);

        System.out.println("Second Set: " + b);

        System.out.println("1. Union");
        System.out.println("2. Intersection");
        System.out.println("3. Difference");
        System.out.print("Enter choice: ");

        int ch = sc.nextInt();

        System.out.println("Result: " + operation(s1, b, ch));

        sc.close();
    }
}
