
import java.util.*;

class StudentMarks {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);

        ArrayList<Integer> marks = new ArrayList<Integer>();

        
        marks.add(75);
        marks.add(80);
        marks.add(65);
        marks.add(90);
        marks.add(85);

       
        System.out.println("Total students: " + marks.size());

      
        System.out.print("Enter index to display marks: ");
        int index = sc.nextInt();

        if (index >= 0 && index < marks.size()) {
            System.out.println("Marks: " + marks.get(index));
        } else {
            System.out.println("Invalid index");
        }

     
        System.out.println("All student marks: " + marks);

      
        System.out.print("Enter index to delete marks: ");
        index = sc.nextInt();

        if (index >= 0 && index < marks.size()) {
            marks.remove(index);
            System.out.println("Marks deleted successfully");
        } else {
            System.out.println("Invalid index");
        }

       
        System.out.println("Updated marks: " + marks);

        sc.close();
    }
}
