
import java.util.*;

class ItemList {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList<String> items = new LinkedList<>();

        items.add("Pen");
        items.add("Book");
        items.add("Pencil");

        System.out.println("Original list: " + items);

        items.addFirst("Bag");
        items.addLast("Scale");
        System.out.println("After insertion: " + items);

        items.add(2, "Eraser");
        System.out.println("At position 2: " + items);

        items.removeFirst();
        items.removeLast();
        items.remove(1);
        System.out.println("After deletion: " + items);

        Collections.sort(items);
        System.out.println("Ascending order: " + items);

        Collections.sort(items, Collections.reverseOrder());
        System.out.println("Descending order: " + items);

        System.out.print("Enter item to search: ");
        String item = sc.nextLine();

        if (items.contains(item))
            System.out.println("Item found");
        else
            System.out.println("Item not found");

        sc.close();
    }
}
