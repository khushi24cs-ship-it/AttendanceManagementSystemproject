class Animal {
    void eat() {
        System.out.println("Animal eats");
    }
}

class Mammal extends Animal {
    @Override
    void eat() {
        System.out.println("Mammal eats");
        super.eat();
    }
}

class Dog extends Mammal {
    @Override
    void eat() {
        System.out.println("Dog eats");
        super.eat();
    }
}

public class AnimalDemo {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.eat();
    }
}
