
import java.util.Scanner;

class Vehicle {
    protected String brand;
    protected int year;

    Vehicle(String brand, int year) {
        this.brand = brand;
        this.year = year;
    }

    void display() {
        System.out.println("Brand: " + brand);
        System.out.println("Year: " + year);
    }
}

class Car extends Vehicle {
    private String model;

    Car(String brand, int year, String model) {
        super(brand, year);
        this.model = model;
    }

    @Override
    void display() {
        super.display();
        System.out.println("Model: " + model);
    }
}

public class VehicleDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter car brand: ");
        String brand = sc.nextLine();

        System.out.print("Enter manufacturing year: ");
        int year = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter car model: ");
        String model = sc.nextLine();

        Car car = new Car(brand, year, model);

        System.out.println("\n----- Car Details -----");
        car.display();

        sc.close();
    }
}
