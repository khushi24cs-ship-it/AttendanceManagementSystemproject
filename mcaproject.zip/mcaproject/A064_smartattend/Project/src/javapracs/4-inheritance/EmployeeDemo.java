
import java.util.Scanner;

class Employee {
    protected int code;
    protected String name;

    Employee(int code, String name) {
        this.code = code;
        this.name = name;
    }

    void display() {
        System.out.println("Code: " + code);
        System.out.println("Name: " + name);
    }
}

class Teacher extends Employee {
    private int lectures;
    private double salaryPerLecture;

    Teacher(int code, String name, int lectures, double salaryPerLecture) {
        super(code, name);
        this.lectures = lectures;
        this.salaryPerLecture = salaryPerLecture;
    }

    double calculate() {
        return lectures * salaryPerLecture;
    }

    @Override
    void display() {
        super.display();
        System.out.println("Number of Lectures: " + lectures);
        System.out.println("Salary per Lecture: " + salaryPerLecture);
        System.out.println("Total Salary: " + calculate());
    }
}

class Manager extends Employee {
    private double salary;
    private int unitOfSales;

    Manager(int code, String name, double salary, int unitOfSales) {
        super(code, name);
        this.salary = salary;
        this.unitOfSales = unitOfSales;
    }

    double calculate() {
        if (unitOfSales < 100) {
            return salary * 0.10;
        } else if (unitOfSales < 200) {
            return salary * 0.15;
        } else {
            return salary * 0.20;
        }
    }

    @Override
    void display() {
        super.display();
        System.out.println("Salary: " + salary);
        System.out.println("Unit of Sales: " + unitOfSales);
        System.out.println("Bonus: " + calculate());
    }
}

public class EmployeeDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Teacher Details:");

        System.out.print("Code: ");
        int tCode = sc.nextInt();
        sc.nextLine();

        System.out.print("Name: ");
        String tName = sc.nextLine();

        System.out.print("Number of Lectures: ");
        int lectures = sc.nextInt();

        System.out.print("Salary per Lecture: ");
        double salaryPerLecture = sc.nextDouble();

        Teacher teacher = new Teacher(
            tCode, tName, lectures, salaryPerLecture
        );

        System.out.println("\nEnter Manager Details:");

        System.out.print("Code: ");
        int mCode = sc.nextInt();
        sc.nextLine();

        System.out.print("Name: ");
        String mName = sc.nextLine();

        System.out.print("Salary: ");
        double salary = sc.nextDouble();

        System.out.print("Unit of Sales: ");
        int sales = sc.nextInt();

        Manager manager = new Manager(
            mCode, mName, salary, sales
        );

        System.out.println("\n----- Teacher Details -----");
        teacher.display();

        System.out.println("\n----- Manager Details -----");
        manager.display();

        sc.close();
    }
}
