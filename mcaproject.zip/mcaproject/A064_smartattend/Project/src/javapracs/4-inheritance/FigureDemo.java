
import java.util.Scanner;

abstract class Figure {
    protected double dim1;
    protected double dim2;

    Figure(double dim1, double dim2) {
        this.dim1 = dim1;
        this.dim2 = dim2;
    }

    abstract double area();
}

class Circle extends Figure {

    Circle(double radius) {
        super(radius, 0);
    }

    @Override
    double area() {
        return Math.PI * dim1 * dim1;
    }
}

class Rectangle extends Figure {

    Rectangle(double length, double breadth) {
        super(length, breadth);
    }

    @Override
    double area() {
        return dim1 * dim2;
    }
}

class Square extends Figure {

    Square(double side) {
        super(side, side);
    }

    @Override
    double area() {
        return dim1 * dim1;
    }
}

public class FigureDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter radius of circle: ");
        double radius = sc.nextDouble();

        System.out.print("Enter length of rectangle: ");
        double length = sc.nextDouble();

        System.out.print("Enter breadth of rectangle: ");
        double breadth = sc.nextDouble();

        System.out.print("Enter side of square: ");
        double side = sc.nextDouble();

        Figure circle = new Circle(radius);
        Figure rectangle = new Rectangle(length, breadth);
        Figure square = new Square(side);

        System.out.println("\nArea of Circle: " + circle.area());
        System.out.println("Area of Rectangle: " + rectangle.area());
        System.out.println("Area of Square: " + square.area());

        sc.close();
    }
}
