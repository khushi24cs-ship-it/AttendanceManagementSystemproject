
import java.util.Scanner;

abstract class BankAccount {
    protected double initialBalance;

    BankAccount(double initialBalance) {
        this.initialBalance = initialBalance;
    }

    abstract void deposit(double amount);

    abstract void withdraw(double amount);
}

class SavingsAccount extends BankAccount {

    SavingsAccount(double initialBalance) {
        super(initialBalance);
    }

    @Override
    void deposit(double amount) {
        if (amount > 0) {
            initialBalance += amount;
            System.out.println("Amount deposited in Savings Account: " + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    @Override
    void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid withdrawal amount.");
        } else if (amount <= initialBalance) {
            initialBalance -= amount;
            System.out.println("Amount withdrawn from Savings Account: " + amount);
        } else {
            System.out.println("Insufficient balance.");
        }
    }

    void display() {
        System.out.println("Savings Account Balance: " + initialBalance);
    }
}

class CheckingAccount extends BankAccount {

    CheckingAccount(double initialBalance) {
        super(initialBalance);
    }

    @Override
    void deposit(double amount) {
        if (amount > 0) {
            initialBalance += amount;
            System.out.println("Amount deposited in Checking Account: " + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    @Override
    void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid withdrawal amount.");
        } else if (amount <= initialBalance) {
            initialBalance -= amount;
            System.out.println("Amount withdrawn from Checking Account: " + amount);
        } else {
            System.out.println("Insufficient balance.");
        }
    }

    void display() {
        System.out.println("Checking Account Balance: " + initialBalance);
    }
}

class Customer {
    private String name;
    private String accountNumber;

    Customer(String name, String accountNumber) {
        this.name = name;
        this.accountNumber = accountNumber;
    }

    void display() {
        System.out.println("Customer Name: " + name);
        System.out.println("Account Number: " + accountNumber);
    }
}

public class BankDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter customer name: ");
        String name = sc.nextLine();

        System.out.print("Enter account number: ");
        String accountNumber = sc.nextLine();

        System.out.print("Enter initial balance for Savings Account: ");
        double savingsBalance = sc.nextDouble();

        System.out.print("Enter initial balance for Checking Account: ");
        double checkingBalance = sc.nextDouble();

        Customer customer = new Customer(name, accountNumber);
        SavingsAccount savings = new SavingsAccount(savingsBalance);
        CheckingAccount checking = new CheckingAccount(checkingBalance);

        System.out.println("\nCustomer Details");
        customer.display();

        System.out.println("\n Savings Account");
        savings.display();

        System.out.print("Enter amount to deposit in Savings Account: ");
        double depositSavings = sc.nextDouble();
        savings.deposit(depositSavings);

        System.out.print("Enter amount to withdraw from Savings Account: ");
        double withdrawSavings = sc.nextDouble();
        savings.withdraw(withdrawSavings);

        savings.display();

        System.out.println("\nChecking Account ");
        checking.display();

        System.out.print("Enter amount to deposit in Checking Account: ");
        double depositChecking = sc.nextDouble();
        checking.deposit(depositChecking);

        System.out.print("Enter amount to withdraw from Checking Account: ");
        double withdrawChecking = sc.nextDouble();
        checking.withdraw(withdrawChecking);

        checking.display();

        sc.close();
    }
}
