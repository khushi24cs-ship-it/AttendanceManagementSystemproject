
interface Employee {
    void work();
    void takeBreak();
}

interface Manager {
    void delegateTask();
    void conductMeeting();
}

class TeamLead implements Employee, Manager {

    @Override
    public void work() {
        System.out.println("TeamLead is working.");
    }

    @Override
    public void takeBreak() {
        System.out.println("TeamLead is taking a break.");
    }

    @Override
    public void delegateTask() {
        System.out.println("TeamLead is delegating tasks.");
    }

    @Override
    public void conductMeeting() {
        System.out.println("TeamLead is conducting a meeting.");
    }
}

public class TeamLeadDemo {
    public static void main(String[] args) {
        TeamLead teamLead = new TeamLead();

        teamLead.work();
        teamLead.takeBreak();
        teamLead.delegateTask();
        teamLead.conductMeeting();
    }
}
