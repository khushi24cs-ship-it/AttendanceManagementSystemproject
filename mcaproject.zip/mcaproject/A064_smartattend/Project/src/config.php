<?php
/**
 * Database and application settings.
 * Change these values to match your local MySQL account (XAMPP default is shown).
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'smartattend');
define('DB_USER', 'root');
define('DB_PASS', '');
define('APP_NAME', 'Smart Attendance Management System');
define('MIN_ATTENDANCE_PERCENT', 80);
