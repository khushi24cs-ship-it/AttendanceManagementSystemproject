# Smart Attendance Management System

**MCA Academic Project | Web Technology + DBMS**

A fully functional web application for managing student attendance in an academic institution. Built with PHP, MySQL, HTML5, CSS3, and JavaScript — no external frameworks.

---

## Features

### Admin
- Manage students, teachers, courses, classes, subjects, and class-subject-teacher assignments
- View real-time dashboard statistics from the database
- View attendance reports for any class-subject combination
- Correct attendance records with a mandatory audit reason
- View the complete correction audit log

### Teacher
- Secure login and personal dashboard showing assigned subjects
- Create attendance sessions (DRAFT or FINALIZED), finalize, or cancel sessions
- Mark attendance — PRESENT, ABSENT, or LATE — for each student in a session
- Edit submitted attendance with a reason recorded in the audit log
- View student-wise reports and identify students below 80%

### Student
- Secure login and personal dashboard
- View enrolled subjects with teacher name and credits
- View subject-wise attendance percentages and eligibility status
- View full session history with individual mark for each session
- Filter attendance history by subject

---

## Attendance Calculation Rule

```
Percentage = (PRESENT + LATE sessions) / Total FINALIZED sessions x 100
```

- `PRESENT` and `LATE` count as attended
- `ABSENT` does not count as attended
- A FINALIZED session with no mark still adds 1 to the denominator (counts as not attended)
- `CANCELLED` and `DRAFT` sessions are excluded entirely
- Minimum requirement: **80% per subject** (exactly 80% is Eligible)
- Eligibility is decided from the precise calculated value, not the rounded display

---

## Technology Stack

| Layer        | Technology                             |
|--------------|----------------------------------------|
| Frontend     | HTML5, CSS3, Vanilla JavaScript        |
| Backend      | PHP 8.x (sessions, PDO, password_hash) |
| Database     | MySQL 5.7+ / MariaDB, InnoDB engine    |
| Local server | XAMPP (Apache + MySQL)                 |

No Laravel, React, Bootstrap, or other frameworks are used.

---

## Prerequisites

- **XAMPP** (or any PHP + MySQL stack): https://www.apachefriends.org/
- PHP 8.x recommended (PHP 7.4+ also works)
- MySQL 5.7+ or MariaDB
- A web browser (Chrome, Firefox, Edge)

---

## Project Folder Structure

```
A064_smartattend/
+-- Project/
|   +-- src/               Application PHP, CSS, and JavaScript
|   |   +-- admin/         Admin pages
|   |   +-- teacher/       Teacher pages
|   |   +-- student/       Student pages
|   |   +-- includes/      Shared header and footer
|   |   +-- css/           style.css
|   |   +-- js/            app.js
|   |   +-- config.php     Database configuration
|   |   +-- db.php         PDO connection
|   |   +-- functions.php  Shared functions, attendance logic
|   |   +-- index.php      Login page
|   |   +-- logout.php     Logout handler
|   +-- sql/
|   |   +-- create_database.sql
|   |   +-- create_tables.sql
|   |   +-- insert_data.sql
|   +-- README.md
+-- Documents/
    +-- Requirements_Specification.docx
```

---

## Setup Instructions

### Step 1 — Start XAMPP

1. Open the XAMPP Control Panel.
2. Click **Start** next to **Apache**.
3. Click **Start** next to **MySQL**.
4. Wait until both show green "Running" status.

### Step 2 — Copy the project

Ensure the project folder is located at:

```
C:\xampp\htdocs\harharmahadev\A064_smartattend\
```

The PHP application lives inside:

```
C:\xampp\htdocs\harharmahadev\A064_smartattend\Project\src\
```

### Step 3 — Import the database (using phpMyAdmin)

1. Open a browser and go to: `http://localhost/phpmyadmin`
2. Click the **SQL** tab (or use **Import**).

Run the three SQL scripts **in this exact order**:

**Script 1 — Create the database:**

File: `Project/sql/create_database.sql`

```sql
-- Paste or import this file first
CREATE DATABASE IF NOT EXISTS smartattend ...
```

**Script 2 — Create the tables:**

File: `Project/sql/create_tables.sql`

**Script 3 — Insert demo data:**

File: `Project/sql/insert_data.sql`

To import via phpMyAdmin:
- Click the **Import** tab
- Choose the file
- Click **Go**
- Repeat for each file in order

To import via MySQL command line (run from the project root):

```bash
mysql -u root -p < Project/sql/create_database.sql
mysql -u root -p smartattend < Project/sql/create_tables.sql
mysql -u root -p smartattend < Project/sql/insert_data.sql
```

### Step 4 — Check database configuration

Open `Project/src/config.php` and confirm these values match your MySQL setup:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'smartattend');
define('DB_USER', 'root');
define('DB_PASS', '');          // Default XAMPP: empty password
```

Change `DB_PASS` if your MySQL root account has a password.

### Step 5 — Run the application

Open your browser and go to:

```
http://localhost/harharmahadev/A064_smartattend/Project/src/index.php
```

This opens the login page.

---

## Demo Credentials

All passwords are stored as PHP `password_hash()` values — never plaintext.

| Role    | Email                           | Password     |
|---------|---------------------------------|--------------|
| Admin   | admin@smartattend.local         | Admin@123    |
| Teacher | teacher1@smartattend.local      | Teacher@123  |
| Student | student1@smartattend.local      | Student@123  |
| Student | student2@smartattend.local      | Student@123  |
| Student | student3@smartattend.local      | Student@123  |
| Student | student4@smartattend.local      | Student@123  |
| Student | student5@smartattend.local      | Student@123  |
| Student | student6@smartattend.local      | Student@123  |

### Demo Attendance Scenarios (after importing insert_data.sql)

The demo data uses two subjects: **Web Technology (WT101)** and **DBMS (DBMS101)**.
Both subjects have 5 finalized sessions. One additional WT session is CANCELLED and one is DRAFT (both excluded from percentages).

| Student     | Roll   | WT Attended | WT % | WT Status | DBMS Attended | DBMS % | DBMS Status   |
|-------------|--------|-------------|------|-----------|---------------|--------|---------------|
| Aarav Shah  | MCA001 | 4/5         | 80%  | Eligible  | 3/5           | 60%    | Below 80%     |
| Diya Patel  | MCA002 | 5/5         | 100% | Eligible  | 4/5           | 80%    | Eligible      |
| Rohan Mehta | MCA003 | 1/5         | 20%  | Below 80% | 1/5           | 20%    | Below 80%     |
| Sneha Iyer  | MCA004 | 2/5         | 40%  | Below 80% | 5/5           | 100%   | Eligible      |
| Kabir Nair  | MCA005 | 5/5         | 100% | Eligible  | 1/5           | 20%    | Below 80%     |
| Meera Joshi | MCA006 | (no marks)  | -    | No data   | (no marks)    | -      | No data       |

> **Note:** LATE marks count as attended. Kabir's WT 100% includes a LATE mark. The audit log also includes a sample correction showing Diya's WT session 5 mark being changed from LATE to PRESENT.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "Unable to connect to the database" | Confirm MySQL is running in XAMPP and the credentials in `config.php` match your setup |
| Page shows a PHP error | Ensure PHP 7.4+ is active. Check XAMPP's PHP version in the XAMPP panel |
| Blank white page | Enable PHP error display by setting `display_errors = On` in `php.ini` |
| "Access denied" opening pages | You are logged in as the wrong role or not logged in; return to `index.php` |
| Sessions expire unexpectedly | Default PHP session lifetime applies; log in again |
| Import fails in phpMyAdmin | Run scripts one at a time in order: create_database.sql first, then create_tables.sql, then insert_data.sql |
| Duplicate entry on re-import | The `create_tables.sql` script drops and recreates all tables. Run it before `insert_data.sql` to reset |

---

## Security Notes

- Passwords use PHP `password_hash()` with the bcrypt algorithm; never stored as plaintext.
- All database queries use PDO prepared statements; no raw SQL string concatenation.
- CSRF tokens protect every state-changing form.
- PHP sessions are regenerated after login; `session_destroy()` is called on logout.
- Role checks are enforced on every server-side action — changing the URL is not sufficient to gain access.
- Output is escaped with `htmlspecialchars()` before rendering.
