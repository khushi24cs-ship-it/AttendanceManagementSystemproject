-- Smart Attendance Management System
-- Step 1: Create the database

CREATE DATABASE IF NOT EXISTS smartattend
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE smartattend;
