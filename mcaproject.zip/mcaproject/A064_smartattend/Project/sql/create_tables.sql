-- Smart Attendance Management System
-- Step 2: Create tables (run after create_database.sql)

USE smartattend;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS attendance_audit_logs;
DROP TABLE IF EXISTS attendance_records;
DROP TABLE IF EXISTS attendance_sessions;
DROP TABLE IF EXISTS class_subjects;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS teachers;
DROP TABLE IF EXISTS classes;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
    user_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'Teacher', 'Student') NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_role (role),
    KEY idx_users_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE courses (
    course_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    course_code VARCHAR(20) NOT NULL,
    course_name VARCHAR(120) NOT NULL,
    duration_years TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (course_id),
    UNIQUE KEY uq_courses_code (course_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE classes (
    class_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    course_id INT UNSIGNED NOT NULL,
    semester TINYINT UNSIGNED NOT NULL,
    division VARCHAR(10) NOT NULL,
    academic_year VARCHAR(9) NOT NULL,
    PRIMARY KEY (class_id),
    UNIQUE KEY uq_classes_def (course_id, semester, division, academic_year),
    KEY idx_classes_course (course_id),
    CONSTRAINT fk_classes_course
        FOREIGN KEY (course_id) REFERENCES courses (course_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE students (
    student_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    roll_no VARCHAR(20) NOT NULL,
    class_id INT UNSIGNED NOT NULL,
    admission_year YEAR NOT NULL,
    status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
    PRIMARY KEY (student_id),
    UNIQUE KEY uq_students_user (user_id),
    UNIQUE KEY uq_students_roll (roll_no),
    KEY idx_students_class (class_id),
    CONSTRAINT fk_students_user
        FOREIGN KEY (user_id) REFERENCES users (user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_students_class
        FOREIGN KEY (class_id) REFERENCES classes (class_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE teachers (
    teacher_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    employee_id VARCHAR(20) NOT NULL,
    department VARCHAR(80) NOT NULL,
    designation VARCHAR(80) NOT NULL,
    PRIMARY KEY (teacher_id),
    UNIQUE KEY uq_teachers_user (user_id),
    UNIQUE KEY uq_teachers_emp (employee_id),
    CONSTRAINT fk_teachers_user
        FOREIGN KEY (user_id) REFERENCES users (user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subjects (
    subject_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    course_id INT UNSIGNED NOT NULL,
    subject_code VARCHAR(20) NOT NULL,
    subject_name VARCHAR(120) NOT NULL,
    semester TINYINT UNSIGNED NOT NULL,
    credits TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (subject_id),
    UNIQUE KEY uq_subjects_code (course_id, subject_code),
    KEY idx_subjects_course (course_id),
    CONSTRAINT fk_subjects_course
        FOREIGN KEY (course_id) REFERENCES courses (course_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE class_subjects (
    class_subject_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    class_id INT UNSIGNED NOT NULL,
    subject_id INT UNSIGNED NOT NULL,
    teacher_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (class_subject_id),
    UNIQUE KEY uq_class_subject (class_id, subject_id),
    KEY idx_cs_teacher (teacher_id),
    KEY idx_cs_subject (subject_id),
    CONSTRAINT fk_cs_class
        FOREIGN KEY (class_id) REFERENCES classes (class_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_cs_subject
        FOREIGN KEY (subject_id) REFERENCES subjects (subject_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_cs_teacher
        FOREIGN KEY (teacher_id) REFERENCES teachers (teacher_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE attendance_sessions (
    session_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    class_subject_id INT UNSIGNED NOT NULL,
    session_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    created_by INT UNSIGNED NOT NULL,
    status ENUM('DRAFT', 'FINALIZED', 'CANCELLED') NOT NULL DEFAULT 'DRAFT',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (session_id),
    UNIQUE KEY uq_session_slot (class_subject_id, session_date, start_time),
    KEY idx_sessions_cs (class_subject_id),
    KEY idx_sessions_status (status),
    KEY idx_sessions_date (session_date),
    CONSTRAINT fk_sessions_cs
        FOREIGN KEY (class_subject_id) REFERENCES class_subjects (class_subject_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_sessions_created
        FOREIGN KEY (created_by) REFERENCES users (user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE attendance_records (
    attendance_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    session_id INT UNSIGNED NOT NULL,
    student_id INT UNSIGNED NOT NULL,
    attendance_status ENUM('PRESENT', 'ABSENT', 'LATE') NOT NULL,
    marked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    remarks VARCHAR(255) NULL,
    PRIMARY KEY (attendance_id),
    UNIQUE KEY uq_record_session_student (session_id, student_id),
    KEY idx_records_student (student_id),
    KEY idx_records_status (attendance_status),
    CONSTRAINT fk_records_session
        FOREIGN KEY (session_id) REFERENCES attendance_sessions (session_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_records_student
        FOREIGN KEY (student_id) REFERENCES students (student_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE attendance_audit_logs (
    audit_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    attendance_id INT UNSIGNED NOT NULL,
    changed_by INT UNSIGNED NOT NULL,
    old_status ENUM('PRESENT', 'ABSENT', 'LATE') NOT NULL,
    new_status ENUM('PRESENT', 'ABSENT', 'LATE') NOT NULL,
    reason VARCHAR(255) NOT NULL,
    changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (audit_id),
    KEY idx_audit_attendance (attendance_id),
    KEY idx_audit_user (changed_by),
    CONSTRAINT fk_audit_record
        FOREIGN KEY (attendance_id) REFERENCES attendance_records (attendance_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_audit_user
        FOREIGN KEY (changed_by) REFERENCES users (user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
