-- Smart Attendance Management System
-- Step 3: Sample demonstration data (run after create_tables.sql)
-- Passwords are PHP password_hash() values. See Project/README.md for login credentials.

USE smartattend;

-- Users: Admin, Teacher, six Students (Meera has no attendance marks on finalized sessions)
INSERT INTO users (user_id, name, email, password_hash, role, is_active) VALUES
(1, 'System Admin', 'admin@smartattend.local', '$2y$10$7DaQV46Bs6xPt5L/TgpQF.EbU9jZIg/piO9CVgdkc.eeYCOz7qMji', 'Admin', 1),
(2, 'Priya Kulkarni', 'teacher1@smartattend.local', '$2y$10$GJQyomb1RASARH/bM1MoVuiLjy.jsED8cFbycHb8MLabGttlQmsfu', 'Teacher', 1),
(3, 'Aarav Shah', 'student1@smartattend.local', '$2y$10$kCkoKXFjvpNPYrlMCRmN1er374IZAmwtHTsc37FwnDMsv20JDPLHG', 'Student', 1),
(4, 'Diya Patel', 'student2@smartattend.local', '$2y$10$kCkoKXFjvpNPYrlMCRmN1er374IZAmwtHTsc37FwnDMsv20JDPLHG', 'Student', 1),
(5, 'Rohan Mehta', 'student3@smartattend.local', '$2y$10$kCkoKXFjvpNPYrlMCRmN1er374IZAmwtHTsc37FwnDMsv20JDPLHG', 'Student', 1),
(6, 'Sneha Iyer', 'student4@smartattend.local', '$2y$10$kCkoKXFjvpNPYrlMCRmN1er374IZAmwtHTsc37FwnDMsv20JDPLHG', 'Student', 1),
(7, 'Kabir Nair', 'student5@smartattend.local', '$2y$10$kCkoKXFjvpNPYrlMCRmN1er374IZAmwtHTsc37FwnDMsv20JDPLHG', 'Student', 1),
(8, 'Meera Joshi', 'student6@smartattend.local', '$2y$10$kCkoKXFjvpNPYrlMCRmN1er374IZAmwtHTsc37FwnDMsv20JDPLHG', 'Student', 1);

INSERT INTO courses (course_id, course_code, course_name, duration_years) VALUES
(1, 'MCA101', 'Master of Computer Applications', 2);

INSERT INTO classes (class_id, course_id, semester, division, academic_year) VALUES
(1, 1, 1, 'A', '2025-26');

INSERT INTO teachers (teacher_id, user_id, employee_id, department, designation) VALUES
(1, 2, 'EMP001', 'Computer Science', 'Assistant Professor');

INSERT INTO students (student_id, user_id, roll_no, class_id, admission_year, status) VALUES
(1, 3, 'MCA001', 1, 2025, 'Active'),
(2, 4, 'MCA002', 1, 2025, 'Active'),
(3, 5, 'MCA003', 1, 2025, 'Active'),
(4, 6, 'MCA004', 1, 2025, 'Active'),
(5, 7, 'MCA005', 1, 2025, 'Active'),
(6, 8, 'MCA006', 1, 2025, 'Active');

INSERT INTO subjects (subject_id, course_id, subject_code, subject_name, semester, credits) VALUES
(1, 1, 'WT101', 'Web Technology', 1, 4),
(2, 1, 'DBMS101', 'Database Management Systems', 1, 4);

INSERT INTO class_subjects (class_subject_id, class_id, subject_id, teacher_id) VALUES
(1, 1, 1, 1),
(2, 1, 2, 1);

-- Web Technology: 5 finalized sessions + 1 cancelled + 1 draft (only FINALIZED sessions count)
INSERT INTO attendance_sessions (session_id, class_subject_id, session_date, start_time, end_time, created_by, status) VALUES
(1, 1, '2025-08-04', '09:00:00', '10:00:00', 2, 'FINALIZED'),
(2, 1, '2025-08-11', '09:00:00', '10:00:00', 2, 'FINALIZED'),
(3, 1, '2025-08-18', '09:00:00', '10:00:00', 2, 'FINALIZED'),
(4, 1, '2025-08-25', '09:00:00', '10:00:00', 2, 'FINALIZED'),
(5, 1, '2025-09-01', '09:00:00', '10:00:00', 2, 'FINALIZED'),
(6, 1, '2025-09-08', '09:00:00', '10:00:00', 2, 'CANCELLED'),
(12, 1, '2025-09-22', '09:00:00', '10:00:00', 2, 'DRAFT');

-- DBMS: 5 finalized sessions
INSERT INTO attendance_sessions (session_id, class_subject_id, session_date, start_time, end_time, created_by, status) VALUES
(7,  2, '2025-08-05', '11:00:00', '12:00:00', 2, 'FINALIZED'),
(8,  2, '2025-08-12', '11:00:00', '12:00:00', 2, 'FINALIZED'),
(9,  2, '2025-08-19', '11:00:00', '12:00:00', 2, 'FINALIZED'),
(10, 2, '2025-08-26', '11:00:00', '12:00:00', 2, 'FINALIZED'),
(11, 2, '2025-09-02', '11:00:00', '12:00:00', 2, 'FINALIZED');

-- WT records (order: Aarav, Diya, Rohan, Sneha, Kabir)
-- Aarav 4/5 = 80% Eligible; Diya 5/5; Rohan 1/5; Sneha 2/5; Kabir 5/5 (includes LATE)
INSERT INTO attendance_records (session_id, student_id, attendance_status, marked_at) VALUES
(1, 1, 'PRESENT', '2025-08-04 10:05:00'),
(1, 2, 'PRESENT', '2025-08-04 10:05:00'),
(1, 3, 'ABSENT',  '2025-08-04 10:05:00'),
(1, 4, 'PRESENT', '2025-08-04 10:05:00'),
(1, 5, 'PRESENT', '2025-08-04 10:05:00'),

(2, 1, 'PRESENT', '2025-08-11 10:05:00'),
(2, 2, 'PRESENT', '2025-08-11 10:05:00'),
(2, 3, 'ABSENT',  '2025-08-11 10:05:00'),
(2, 4, 'ABSENT',  '2025-08-11 10:05:00'),
(2, 5, 'LATE',    '2025-08-11 10:05:00'),

(3, 1, 'PRESENT', '2025-08-18 10:05:00'),
(3, 2, 'PRESENT', '2025-08-18 10:05:00'),
(3, 3, 'ABSENT',  '2025-08-18 10:05:00'),
(3, 4, 'ABSENT',  '2025-08-18 10:05:00'),
(3, 5, 'PRESENT', '2025-08-18 10:05:00'),

(4, 1, 'PRESENT', '2025-08-25 10:05:00'),
(4, 2, 'PRESENT', '2025-08-25 10:05:00'),
(4, 3, 'PRESENT', '2025-08-25 10:05:00'),
(4, 4, 'PRESENT', '2025-08-25 10:05:00'),
(4, 5, 'PRESENT', '2025-08-25 10:05:00'),

(5, 1, 'ABSENT',  '2025-09-01 10:05:00'),
(5, 2, 'PRESENT', '2025-09-01 10:05:00'),
(5, 3, 'ABSENT',  '2025-09-01 10:05:00'),
(5, 4, 'ABSENT',  '2025-09-01 10:05:00'),
(5, 5, 'PRESENT', '2025-09-01 10:05:00');

-- DBMS records
-- Aarav 3/5 = 60% Below; Diya 4/5 = 80%; Rohan 1/5; Sneha 5/5; Kabir 1/5
INSERT INTO attendance_records (session_id, student_id, attendance_status, marked_at) VALUES
(7, 1, 'PRESENT', '2025-08-05 12:05:00'),
(7, 2, 'PRESENT', '2025-08-05 12:05:00'),
(7, 3, 'ABSENT',  '2025-08-05 12:05:00'),
(7, 4, 'PRESENT', '2025-08-05 12:05:00'),
(7, 5, 'ABSENT',  '2025-08-05 12:05:00'),

(8, 1, 'PRESENT', '2025-08-12 12:05:00'),
(8, 2, 'PRESENT', '2025-08-12 12:05:00'),
(8, 3, 'ABSENT',  '2025-08-12 12:05:00'),
(8, 4, 'PRESENT', '2025-08-12 12:05:00'),
(8, 5, 'ABSENT',  '2025-08-12 12:05:00'),

(9, 1, 'ABSENT',  '2025-08-19 12:05:00'),
(9, 2, 'PRESENT', '2025-08-19 12:05:00'),
(9, 3, 'ABSENT',  '2025-08-19 12:05:00'),
(9, 4, 'PRESENT', '2025-08-19 12:05:00'),
(9, 5, 'PRESENT', '2025-08-19 12:05:00'),

(10, 1, 'PRESENT', '2025-08-26 12:05:00'),
(10, 2, 'PRESENT', '2025-08-26 12:05:00'),
(10, 3, 'ABSENT',  '2025-08-26 12:05:00'),
(10, 4, 'PRESENT', '2025-08-26 12:05:00'),
(10, 5, 'ABSENT',  '2025-08-26 12:05:00'),

(11, 1, 'ABSENT',  '2025-09-02 12:05:00'),
(11, 2, 'ABSENT',  '2025-09-02 12:05:00'),
(11, 3, 'PRESENT', '2025-09-02 12:05:00'),
(11, 4, 'PRESENT', '2025-09-02 12:05:00'),
(11, 5, 'ABSENT',  '2025-09-02 12:05:00');

-- Sample correction: Diya WT session 5 was LATE, then marked PRESENT
INSERT INTO attendance_audit_logs (attendance_id, changed_by, old_status, new_status, reason, changed_at)
SELECT attendance_id, 2, 'LATE', 'PRESENT', 'Student arrived; biometric confirmed presence', '2025-09-01 16:20:00'
FROM attendance_records
WHERE session_id = 5 AND student_id = 2;
